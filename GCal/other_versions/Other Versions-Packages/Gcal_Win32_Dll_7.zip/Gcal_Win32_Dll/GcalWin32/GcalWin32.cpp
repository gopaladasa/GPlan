// GcalWin32.cpp : Defines the exported functions for the DLL application.
//




// gcalc.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"

#include "stdafx.h"



#include <stdio.h>
#include "platform.h"
#include "TCommand.h"
#include "ctype.h"
#include "stdlib.h"
//#define const_cast(x) ((char *)(x))
#define FNAME "d:\\XMLOutput.txt"

Boolean GCalApp_InitInstance();//char * args[], int argn);
void GCalApp_ExitInstance();
const char * AvcGetVersionText();

const char *g_str_help = "Use commands:\n"
"c - calculate calendar\nn - calculate next day\np - calculate previous day\n"
"t - calculate today\na - calculate appearance day\ne - calculate events\n"
"m - calculate masa list\nexp-oe - export observed events\nhelp - print this help\n"
"\n";


//----------------------
extern "C" __declspec(dllexport) char * AnalyzeQueryString(char *mQueryString);
void MainWnd_CalcCalendar();
void MainWnd_OnCalcToday();
void MainWnd_CalcAppDay();
void MainWnd_CalcEvents();
void MainWnd_CalcMasaList();
void MainWnd_OnCalcNextDay();
void MainWnd_OnCalcPrevDay();
void MainWnd_List(int n);
void MainWnd_Save();
void DlgObservedEventsExport();
void DlgCustomEvent();
void DlgSetAyanamsaType();
void DlgSelectLangOutput();
void DlgShowSet();
void DlgSetMy();
void DlgExport();
void DlgLocations();
void DlgEventFinder();


extern "C" __declspec(dllexport) HRESULT __stdcall
DllRegisterServer(void)
{
	return S_OK;
}
void ExecuteCommand(TCommand &cmd)
{
	if (cmd == "c")
	{
		MainWnd_CalcCalendar();
	}
	else if (cmd == "n")
	{
		MainWnd_OnCalcNextDay();
	}
	else if (cmd == "p")
	{
		MainWnd_OnCalcPrevDay();
	}
	else if (cmd == "t")
	{
		MainWnd_OnCalcToday();
	}
	else if (cmd == "a")
	{
		MainWnd_CalcAppDay();
	}
	else if (cmd == "e")
	{
		MainWnd_CalcEvents();
	}
	else if (cmd == "m")
	{
		MainWnd_CalcMasaList();
	}
	else if (cmd == "export")
	{
		DlgExport();
	}
	else if (cmd == "help")
	{
		printf(g_str_help);
	}
	else if (cmd == "la")
	{
		MainWnd_List(1);
	}
	else if (cmd == "lc")
	{
		MainWnd_List(2);
	}
	else if (cmd == "le")
	{
		MainWnd_List(3);
	}
	else if (cmd == "lm")
	{
		MainWnd_List(4);
	}
	else if (cmd == "save")
	{
		MainWnd_Save();
	}
	else if (cmd == "custom")
	{
		DlgCustomEvent();
	}
	else if (cmd == "ayanamsa")
	{
		DlgSetAyanamsaType();
	}
	else if (cmd == "setlang")
	{
		DlgSelectLangOutput();
	}
	else if (cmd == "showset")
	{
		DlgShowSet();
	}
	else if (cmd == "setmy")
	{
		DlgSetMy();
	}
	else if (cmd == "locs")
	{
		DlgLocations();
	}
	else if (cmd == "find")
	{
		DlgEventFinder();
	}
}

#include "ttimezone.h"
#include "math.h"
#include "astro.h"


int FindNextTimeZone(double & d)
{
	double thisD = d;
	double newD = 1000.0;
	for(int i = 0; i < TTimeZone::GetTimeZoneCount(); i++)
	{
		if (TTimeZone::gzone[i].tzone > thisD && TTimeZone::gzone[i].tzone < newD)
		{
			newD = TTimeZone::gzone[i].tzone;
		}
	}

	if (newD > 999.0)
		return 0;
	d = newD;
	return 1;
}

int htoi(char s)
{
	if (isdigit(s))
		return int(s - '0');
	if (s >= 'a' && s <= 'f')
		return int(s - 'a' + 10);
	if (s >= 'A' && s <= 'F')
		return int(s - 'A' + 10);
	return 0;
}

void DecodeQueryArgument(char * in_p)
{
	char * p = in_p;
	char * d = in_p;

	while(*p)
	{
		if (*p == '%')
		{
			*d = htoi(p[1])*16 + htoi(p[2]);
			p += 2;
		}
		else if (*p == '+')
		{
			*p = ' ';
		}

		p++;
		d++;
	}
	*d = 0;
}

#include "astro.h"
#include "avc.h"

char * WriteXML_FirstDay_Year(FILE * fout, CLocation & loc, VCTIME vcStart);
void WriteAppDayHTML(TResultApp &app, FILE *F);
int WriteCalendarHTML(TResultCalendar &daybuff, FILE * fout);
void CalcAppDay(CLocation &, VCTIME, TResultApp &);
VCTIME GetFirstDayOfYear(EARTHDATA, int);


double EarthPosToDouble(const char *str)
{
	double l = 0.0;
	double sig = 1.0;
	double coma = 10.0;
	bool after_coma = false;
	bool is_deg = false;

	const char * s = str;

	while(*s)
	{
		switch(*s)
		{
		case '0': case '1':
		case '2': case '3': case '4': case '5':
		case '6': case '7': case '8': case '9':
			if (after_coma)
			{
				if (is_deg)
				{
					l += (*s - '0') * 5.0 / (coma * 3.0);
				}
				else
				{
					l += (*s - '0') / coma;
				}
				coma *= 10.0;
			}
			else
			{
				l = l*10.0 + (*s - '0');
			}
			break;
		case 'e': case 'E':
		case 'n': case 'N':
			after_coma = true;
			is_deg = true;
			sig = 1.0;
			break;
		case 'w': case 'W':
		case 's': case 'S':
			after_coma = true;
			is_deg = true;
			sig = -1.0;
			break;
		default:
			break;
		}
		s++;
	}

	return l * sig;
}

char * szArgQuery;
char * szArgLat;
char * szArgLon;
char * szArgTz;
char * szArgName;
char * szArgYear;
char * szArgMonth;
char * szArgDay;
char * szArgHour;
char * szArgMin;
char * szArgCount;
int AvcComboMasaToMasa(int);

int file_length(FILE *f)
{
int pos;
int end;

pos = ftell (f);
fseek (f, 0, SEEK_END);
end = ftell (f);
fseek (f, pos, SEEK_SET);

return end;
}




char * AnalyzeQueryString(char *mQueryString)
{	
	
	char XMLOut[5000];	
	
	char szQuery[1024];
	char * args[80][2];
	int argn, u;
	CLocation loc;
	VCTIME vc;
	int nCount = 1;
	int gy, gm, gp, gt, tye;
	EARTHDATA earth;
	int nQueryLength;

	GCalApp_InitInstance();
	gy = 500;
	gm = 1;
	gp = 0;
	gt = 1;
	tye = 0;

	vc.Today();
	vc.shour = 0.0;
	szArgQuery = "";
	szArgLat = "";
	szArgLon = "";
	szArgTz = "";
	szArgName = "";
	szArgYear = "";
	szArgMonth = "";
	szArgDay = "";
	szArgHour = "";
	szArgMin = "";
	szArgCount = "";
	
//	_putenv("QUERY_STRING=q=firstday&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009");

//	_putenv("QUERY_STRING=q=firstday&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009");
//	_putenv("QUERY_STRING=q=appday&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=10&th=3&tmin=45");
//	_putenv("QUERY_STRING=q=sankranti&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=10&tc=5");
//	_putenv("QUERY_STRING=q=calendar&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=10&tc=5");
//	_putenv("QUERY_STRING=q=naksatra&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=10&tc=5");
//	_putenv("QUERY_STRING=q=gtithi&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tye=2012&gm=5&gp=0&gt=10");
//	_putenv("QUERY_STRING=q=tithi&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=15");
//	_putenv("QUERY_STRING=q=next&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=15&gm=5&gp=0&gt=10");
//	_putenv("QUERY_STRING=q=gnaksatra&lc=Test+City&la=28N09&lo=77E40&lt=5E30&gy=520&gm=5");

	//const char * pq =  getenv("QUERY_STRING");
//	strcpy(mQueryString,"QUERY_STRING=q=firstday&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009");

	//if (mQueryString == NULL)
	//	goto no_query;


	strcpy(szQuery, mQueryString);

	nQueryLength = strlen(szQuery);
	if(nQueryLength<5)
		goto lblInvalidQS;

	argn = 0;
	args[0][0] = szQuery;
	args[0][1] = szQuery;

	for(u = 0; u < nQueryLength; u++)
	{
		if (szQuery[u] == '&')
		{
			argn++;
			args[argn][0] = szQuery + u + 1;
			args[argn][1] = args[argn][0];
			szQuery[u] = 0;
		}
		else if (szQuery[u] == '=')
		{
			args[argn][1] = szQuery + u + 1;
			szQuery[u] = 0;
		}
	}

	argn++;

	for(u = 0; u < argn; u++)
	{
		DecodeQueryArgument(args[u][1]);
		//printf("%s -> %s\n", args[u][0], args[u][1]);
		if (strcmp(args[u][0], "la")==0)
		{
			szArgLat = args[u][1];
			loc.m_fLatitude = EarthPosToDouble(szArgLat);
		}
		else if (strcmp(args[u][0], "q")==0)
		{
			szArgQuery = args[u][1];
		}
		else if (strcmp(args[u][0], "lo")==0)
		{
			szArgLon = args[u][1];
			loc.m_fLongitude = EarthPosToDouble(szArgLon);
		}
		else if (strcmp(args[u][0], "lt")==0)
		{
			szArgTz = args[u][1];
			loc.m_fTimezone = EarthPosToDouble(szArgTz);
		}
		else if (strcmp(args[u][0], "lc")==0)
		{
			szArgName = args[u][1];
			loc.m_strCity = szArgName;
		}
		else if (strcmp(args[u][0], "ty")==0)
		{
			szArgYear = args[u][1];
			vc.year = atoi(szArgYear);
		}
		else if (strcmp(args[u][0], "tye")==0)
		{
			tye = atoi(args[u][1]);
		}
		else if (strcmp(args[u][0], "tm")==0)
		{
			szArgMonth = args[u][1];
			vc.month = atoi(szArgMonth);
		}
		else if (strcmp(args[u][0], "td")==0)
		{
			szArgDay = args[u][1];
			vc.day = atoi(szArgDay);
		}
		else if (strcmp(args[u][0], "th")==0)
		{
			szArgHour = args[u][1];
			vc.shour += atoi(szArgHour)/24.0;
		}
		else if (strcmp(args[u][0], "tmin")==0)
		{
			szArgMin = args[u][1];
			vc.shour += atoi(szArgMin)/1440.0;
		}
		else if (strcmp(args[u][0], "tc")==0)
		{
			szArgCount = args[u][1];
			nCount = atoi(szArgCount);
		}
		else if (strcmp(args[u][0], "gy")==0)
		{
			gy = atoi(args[u][1]);
		}
		else if (strcmp(args[u][0], "gm")==0)
		{
			gm = atoi(args[u][1]);
		}
		else if (strcmp(args[u][0], "gp")==0)
		{
			gp = atoi(args[u][1]);
		}
		else if (strcmp(args[u][0], "gt")==0)
		{
			gt = atoi(args[u][1]);
		}
		else if (strcmp(args[u][0], "dst")==0)
		{
			unsigned int a[10];
			int curra = 0;
			int i;
			char szbuffa[64];
			for(i = 0; i< 10; i++) { a[i]=0; }
			strcpy(szbuffa, args[u][1]);
			for(i = 0; curra<10 && szbuffa[i] != 0; i++)
			{
				if (szbuffa[i]=='x') curra++;
				else if (isdigit(szbuffa[i])) a[curra] = 10*a[curra]+(szbuffa[i]-'0');
			}
			loc.m_nDST = a[0];
			loc.m_nDST = (loc.m_nDST << 6) | a[1];
			loc.m_nDST = (loc.m_nDST << 2) | a[2];
			loc.m_nDST = (loc.m_nDST << 4) | a[3];
			loc.m_nDST = (loc.m_nDST << 4) | a[4];
			loc.m_nDST = (loc.m_nDST << 6) | a[5];
			loc.m_nDST = (loc.m_nDST << 2) | a[6];
			loc.m_nDST = (loc.m_nDST << 4) | a[7];
		}
	}

	earth = (EARTHDATA)loc;

	//printf("\nQuery:\n%s\n\n", getenv("QUERY_STRING"));

//no_query:
	//printf("Content-type: text/xml\n\n");

	
	if (strcmp(szArgQuery,"firstday")==0)
	{
		return WriteXML_FirstDay_Year(stdout, loc, vc);
		//strcpy(XMLOut,WriteXML_FirstDay_Year(stdout, loc, vc));
		//return XMLOut;
	}
	else if (strcmp(szArgQuery,"appday")==0)
	{
		TResultApp app;
		TString str;
		CalcAppDay(loc, vc, app);
		FormatAppDayXML(app, str);		
		//return const_cast(str.c_str());		
		int n = strlen(str.c_str());
		char * XML = new char[n];
		strcpy(XML, str.c_str());	
	/*	FILE *stream;
		stream = fopen( FNAME, "a" );	
		fwrite(str.c_str(),sizeof(char),strlen(str.c_str()),stream);
		fwrite("chitra\n",sizeof(char),8,stream);
		fwrite(XMLOut,sizeof(char),strlen(XMLOut),stream);
		fclose(stream);*/

	
		//strcpy(XMLOut, str.c_str());	
	
		return XML;
	}
	else if (strcmp(szArgQuery,"sankranti")==0)
	{
		VCTIME vc2;
		vc2 = vc;
		vc2 += nCount;
		return WriteXML_Sankrantis(stdout, loc, vc, vc2);
		//strcpy(XMLOut,WriteXML_Sankrantis(stdout, loc, vc, vc2));
		//return XMLOut;
	}
	else if (strcmp(szArgQuery,"calendar")==0)
	{
		TResultCalendar cal;
		vc.shour = 0;
		CalcCalendar(cal, loc, vc, nCount);
		return WriteCalendarXml(cal, stdout);
		//strcpy(XMLOut,WriteCalendarXml(cal, stdout));
		//return XMLOut;
	}
	else if (strcmp(szArgQuery,"gcalendar")==0)
	{
		VCTIME vc2;

		vc = GetFirstDayOfYear(earth, vc.year);
		vc.InitWeekDay();
		vc.shour = 0;

		vc2 = GetFirstDayOfYear(earth, vc.year + 1);
		vc2.InitWeekDay();
		vc2.shour = 0;

		TResultCalendar cal;
		vc.shour = 0;
		CalcCalendar(cal, loc, vc, int(vc2.GetJulian() - vc.GetJulian()));
		return WriteCalendarXml(cal, stdout);
		//strcpy(XMLOut,WriteCalendarXml(cal, stdout));
		//return XMLOut;
	}
	else if (strcmp(szArgQuery,"naksatra")==0)
	{
		return WriteXML_Naksatra(stdout, loc, vc, nCount);
		//strcpy(XMLOut,WriteXML_Naksatra(stdout, loc, vc, nCount));
		//return XMLOut;
	}
	else if (strcmp(szArgQuery,"gtithi")==0)
	{
		VATIME va1;
		VATIME va2;
		va1.gyear = vc.year - 1486;
		va1.masa = gm;
		va1.tithi = gp*15 + gt - 1;
		va2 = va1;
		va2.gyear = tye - 1486;
		return WriteXML_GaurabdaTithi( stdout, loc, va1, va2);
		//strcpy(XMLOut,WriteXML_GaurabdaTithi( stdout, loc, va1, va2));
		//return XMLOut;
		
	}
	else if (strcmp(szArgQuery,"tithi")==0)
	{
		return WriteXML_Tithi( stdout, loc, vc);
		//strcpy(XMLOut,WriteXML_Tithi( stdout, loc, vc));
		//return XMLOut;
		
	}
	else if (strcmp(szArgQuery,"masastart")==0)
	{
		return WriteXML_MasaStart( stdout, loc, vc, 0);
	}
	else if (strcmp(szArgQuery,"paksastart")==0)
	{
		return WriteXML_MasaStart( stdout, loc, vc, 1);
	}
	else if (strcmp(szArgQuery,"next")==0)
	{
		VATIME va;
		va.masa = AvcComboMasaToMasa(gm);
		va.tithi = gt - 1 + gp*15;
		return WriteXML_GaurabdaNextTithi( stdout, loc, vc, va);
		//strcpy(XMLOut,WriteXML_GaurabdaNextTithi( stdout, loc, vc, va));
		//return XMLOut;
	}
	else if (strcmp(szArgQuery,"gnaksatra")==0)
	{
		vc = GetFirstDayOfMasa(earth, gy, AvcComboMasaToMasa(gm));
		return WriteXML_Naksatra( stdout, loc, vc, nCount);
		//strcpy(XMLOut,WriteXML_Naksatra( stdout, loc, vc, nCount));
		//return XMLOut;
	}
	else
	{
lblInvalidQS:
		strcpy(XMLOut,"Invalid format of Query string");	
		return XMLOut;
	
	}		

	//return XMLOut;
	
	

	


}
	


/*int main(int argc, char* argv[])
{
	TCommand cmd;
	char * str =new char[100];	

	// test for command line arguments
	// if no cmd line args, then processing manual commands
	// from console
	if (GCalApp_InitInstance(argv, argc)==true)
	{
		// processing of commands
	

		strcpy(str,"q=calendar&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=10&tc=5");
		//strcpy(str,"q=sankranti&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=10&tc=5");
		//strcpy(str,"q=calendar&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=10&tc=5");
		//strcpy(str,"q=tithi&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=15");
		//strcpy(str,"q=naksatra&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=10&tc=5");
		//strcpy(str,"q=appday&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tm=5&td=10&th=3&tmin=45");
		//strcpy(str,"q=gtithi&lc=Test+City&la=28N09&lo=77E40&lt=5E30&ty=2009&tye=2012&gm=5&gp=0&gt=10");
		//strcpy(str,"q=gnaksatra&lc=Test+City&la=28N09&lo=77E40&lt=5E30&gy=520&gm=5");
		AnalyzeQueryString(str);
		

		// exit from app
		GCalApp_ExitInstance();
	}
	
	getchar();

	return 0;
}*/

