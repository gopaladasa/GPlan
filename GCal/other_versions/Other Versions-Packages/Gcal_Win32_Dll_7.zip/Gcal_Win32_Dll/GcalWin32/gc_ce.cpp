// CustomEvent.cpp: implementation of the CCustomEvent class.
//
//////////////////////////////////////////////////////////////////////

#include "avc.h"
#include "TFile.h"

//==============================================================
//
//==============================================================

TString gCustomEventTexts[360];

//==============================================================
//
//==============================================================

CCustomEventList gCustomEventList;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCustomEvent::CCustomEvent()
{
	next = NULL;
}

//==============================================================
//
//==============================================================

CCustomEvent::~CCustomEvent()
{

}

CCustomEvent * CCustomEventList::add(void)
{
	CCustomEvent * p;

	p = list;
	if (list == NULL)
	{
		list = new CCustomEvent;
		return list;
	}
	while(p->next != NULL)
		p = p->next;
	p->next = new CCustomEvent;
	return (p->next);
}

//==============================================================
//
//==============================================================

int CustomEventListReadFile(const char * pszFile)
{
	gCustomEventList.clear();

	TFile csd;
	int tithi, masa;
	TString strA, strB, text;
	CCustomEvent * pce;
	int nRet = -1;

	for(tithi = 0; tithi < 360; tithi++)
	{
		gCustomEventTexts[tithi].Empty();
	}

	if (csd.Open(pszFile, "r") == true)
	{
		nRet ++;
		while(csd.ReadPropertyLine(strA, strB))
		{
			if (strA.CompareNoCase("event") == 0)
			{
				nRet++;
				if (strB.GetLength() > 2)
				{
					strB.Mid(2, strB.GetLength(), text);
					pce = gCustomEventList.add();
					if (pce)
					{
						pce->nTithi  = tithi = strB.GetAt(0) - '@';
						pce->nMasa   = masa  = strB.GetAt(1) - '@';
						pce->strText = text;
					}

					if (tithi >= 0 && tithi < 30 && masa >= 0 && masa < 12)
					{
						if (gCustomEventTexts[tithi + masa*30].IsEmpty() == true)
						{
							gCustomEventTexts[tithi + masa*30] = "[c6]";
							gCustomEventTexts[tithi + masa*30] += text;
						}
						else
						{
							gCustomEventTexts[tithi + masa*30] += "#[c6]";
							gCustomEventTexts[tithi + masa*30] += text;
						}
					}
				}
			}
		}

		csd.Close();
	}


	return nRet;
}

//==============================================================
//
//==============================================================

int CustomEventListWriteFile(const char * pszFile)
{
	TFile csd;
	TString str;
	CCustomEvent * pce;
	int nRet = -1;

	if (csd.Open(pszFile, "w") == true)
	{
		nRet ++;
		pce = gCustomEventList.list;

		while(pce)
		{
			nRet ++;
			// write to file
			str.Format("event=%c%c%s\n", '@' + pce->nTithi, '@' + pce->nMasa, pce->strText.c_str());
			csd.WriteString(str);

			pce = pce->next;
		}
		// close file
		csd.Close();
	}

	return nRet;
}

//==============================================================
//
//==============================================================

//==============================================================
//
//==============================================================

//==============================================================
//
//==============================================================


void CCustomEventList::clear()
{
	CCustomEvent * p, * r;

	p = list;
	while(p)
	{
		r = p->next;
		delete p;
		p = r;
	}
	list = NULL;
}
