/*
#define MAX_CONDS 5
*/
#include "avc.h"

extern CLocation gLastLocation;

TEventClass g_egroup[] =
{
	{1, "mahadvadasi"},
	{2, "sankranti"},
	{8, "tithi"},
	{9, "paksa"},
	{3, "tithi+paksa"},
	{4, "naksatra"},
	{5, "yoga"},
	{6, "fasting day"},
	{7, "day of week"},
	{10,"text"},
};

TEventValue g_eval[] =
{
	{1, EV_UNMILANI, "Unmilani Mahadvadasi"},
	{1, EV_TRISPRSA, "Trisprsa Mahadvadasi"},
	{1, EV_UNMILANI_TRISPRSA, "Unmilani Trisprsa Mahadvadasi"},
	{1, EV_PAKSAVARDHINI, "Paksavardhini Mahadvadasi"},
	{1, EV_JAYA, "Jaya Mahadvadasi"},
	{1, EV_VIJAYA, "Vijaya Mahadvadasi"},
	{1, EV_PAPA_NASINI, "Papa Nasini Mahadvadasi"},
	{1, EV_JAYANTI, "Jayanti Mahadvadasi"},
	{1, EV_VYANJULI, "Vyanjuli Mahadvadasi"},

	{2,  0, "Mesa (Aries)"},
	{2,  1, "Vrsabha (Taurus)"},
	{2,  2, "Mithuna (Gemini)"},
	{2,  3, "Karka (Cancer)"},
	{2,  4, "Simha (Leo)"},
	{2,  5, "Kanya (Virgo)"},
	{2,  6, "Tula (Libra)"},
	{2,  7, "Vrscika (Scorpio)"},
	{2,  8, "Dhanus (Sagittarius)"},
	{2,  9, "Makara (Capricorn)"},
	{2, 10, "Kumbha (Aquarius)"},
	{2, 11, "Mina (Pisces)"},

	{3, 0, "Pratipat, Krsna Paksa"},
	{3, 1, "Dvitiya, Krsna Paksa"},
	{3, 2, "Tritiya, Krsna Paksa"},
	{3, 3, "Caturthi, Krsna Paksa"},
	{3, 4, "Pancami, Krsna Paksa"},
	{3, 5, "Sasti, Krsna Paksa"},
	{3, 6, "Saptami, Krsna Paksa"},
	{3, 7, "Astami, Krsna Paksa"},
	{3, 8, "Navami, Krsna Paksa"},
	{3, 9, "Dasami, Krsna Paksa"},
	{3, 10, "Ekadasi, Krsna Paksa"},
	{3, 11, "Dvadasi, Krsna Paksa"},
	{3, 12, "Trayodasi, Krsna Paksa"},
	{3, 13, "Caturdasi, Krsna Paksa"},
	{3, 14, "Amavasya, Krsna Paksa"},
	{3, 15, "Pratipat, Gaura Paksa"},
	{3, 16, "Dvitiya, Gaura Paksa"},
	{3, 17, "Tritiya, Gaura Paksa"},
	{3, 18, "Caturthi, Gaura Paksa"},
	{3, 19, "Pancami, Gaura Paksa"},
	{3, 20, "Sasti, Gaura Paksa"},
	{3, 21, "Saptami, Gaura Paksa"},
	{3, 22, "Astami, Gaura Paksa"},
	{3, 23, "Navami, Gaura Paksa"},
	{3, 24, "Dasami, Gaura Paksa"},
	{3, 25, "Ekadasi, Gaura Paksa"},
	{3, 26, "Dvadasi, Gaura Paksa"},
	{3, 27, "Trayodasi, Gaura Paksa"},
	{3, 28, "Caturdasi, Gaura Paksa"},
	{3, 29, "Purnima, Gaura Paksa"},

	{4, 0, "Asvini Naksatra"},
	{4, 1, "Bharani Naksatra"},
	{4, 2, "Krittika Naksatra"},
	{4, 3, "Rohini Naksatra"},
	{4, 4, "Mrigasira Naksatra"},
	{4, 5, "Ardra Naksatra"},
	{4, 6, "Punarvasu Naksatra"},
	{4, 7, "Pusyami Naksatra"},
	{4, 8, "Aslesa Naksatra"},
	{4, 9, "Magha Naksatra"},
	{4, 10, "Purva-phalguni Naksatra"},
	{4, 11, "Uttara-phalguni Naksatra"},
	{4, 12, "Hasta Naksatra"},
	{4, 13, "Citra Naksatra"},
	{4, 14, "Swati Naksatra"},
	{4, 15, "Visakha Naksatra"},
	{4, 16, "Anuradha Naksatra"},
	{4, 17, "Jyestha Naksatra"},
	{4, 18, "Mula Naksatra"},
	{4, 19, "Purva-asadha Naksatra"},
	{4, 20, "Uttara-asadha Naksatra"},
	{4, 21, "Sravana Naksatra"},
	{4, 22, "Dhanista Naksatra"},
	{4, 23, "Satabhisa Naksatra"},
	{4, 24, "Purva-bhadra Naksatra"},
	{4, 25, "Uttara-bhadra Naksatra"},
	{4, 26, "Revati Naksatra"},

	{5, 0, "Viskumba Yoga"}, 
	{5, 1, "Priti Yoga"}, 
	{5, 2, "Ayusmana Yoga"}, 
	{5, 3, "Saubhagya Yoga"}, 
	{5, 4, "Sobana Yoga"}, 
	{5, 5, "Atiganda Yoga"}, 
	{5, 6, "Sukarma Yoga"}, 
	{5, 7, "Dhriti Yoga"}, 
	{5, 8, "Sula Yoga"}, 
	{5, 9, "Ganda Yoga"}, 
	{5, 10, "Vriddhi Yoga"}, 
	{5, 11, "Dhruva Yoga"}, 
	{5, 12, "Vyagata Yoga"}, 
	{5, 13, "Harsana Yoga"}, 
	{5, 14, "Vajra Yoga"}, 
	{5, 15, "Siddhi Yoga"}, 
	{5, 16, "Vyatipata Yoga"}, 
	{5, 17, "Variyana Yoga"}, 
	{5, 18, "Parigha Yoga"}, 
	{5, 19, "Siva Yoga"}, 
	{5, 20, "Siddha Yoga"}, 
	{5, 21, "Sadhya Yoga"}, 
	{5, 22, "Subha Yoga"}, 
	{5, 23, "Sukla Yoga"}, 
	{5, 24, "Brahma Yoga"}, 
	{5, 25, "Indra Yoga"}, 
	{5, 26, "Vaidhriti Yoga"}, 

	{6, 0, "<all fasting days>"},
	{6, 1, "(Fast till noon)"},
	{6, 2, "(Fast till sunset)"},
	{6, 3, "(Fast till moonrise)"},
	{6, 4, "(Fast till dusk)"},
	{6, 5, "(Fast till midnight)"},
	{6, 6, "(Fasting for Ekadasi)"},

	{7, 0, "Sunday"},
	{7, 1, "Monday"},
	{7, 2, "Tuesday"},
	{7, 3, "Wednesday"},
	{7, 4, "Thursday"},
	{7, 5, "Friday"},
	{7, 6, "Saturday"},

	{8, 0, "Pratipat"},
	{8, 1, "Dvitiya"},
	{8, 2, "Tritiya"},
	{8, 3, "Caturthi"},
	{8, 4, "Pancami"},
	{8, 5, "Sasti"},
	{8, 6, "Saptami"},
	{8, 7, "Astami"},
	{8, 8, "Navami"},
	{8, 9, "Dasami"},
	{8, 10, "Ekadasi"},
	{8, 11, "Dvadasi"},
	{8, 12, "Trayodasi"},
	{8, 13, "Caturdasi"},
	{8, 14, "Amavasya//Purnima"},

	{9, 1, "Gaura"},
	{9, 0, "Krsna"},
};

Boolean ConditionEvaluate(VAISNAVADAY *pd, int nClass, int nValue, TString &strText, Boolean defReturn);
int FormatCalendarDayText(VAISNAVADAY *, TString &);

//===========================================================================================
//
//===========================================================================================

Boolean TEventFinder::Test(VAISNAVADAY * pd)
{
	int i;

	if (b_and == true)
	{
		// and == true, that means we are applying operator AND
		// that means ALL conditions must be TRUE, that means if some condition
		// is FALSE, then we will return FALSE, otherwise return TRUE
		for(i = 0; i < v_num; i++)
		{
			if (!ConditionEvaluate(pd, v[i].group, v[i].value, vt[i], b_and))
				return false;
		}
		return true;
	}
	else
	{
		// and == false, that means we are applying operator OR
		// that means AT LEAST ONE condition must be TRUE, that means
		// we return TRUE for first condition with result TRUE
		// otherwise we return FALSE
		for(i = 0; i < v_num; i++)
		{
			if (ConditionEvaluate(pd, v[i].group, v[i].value, vt[i], b_and))
				return true;
		}
		return false;
	}

}

//===========================================================================================
//
//===========================================================================================

Boolean TEventFinder::canTest()
{
	for(int i = 0; i < v_num; i++)
		if (v[i].group != 0)
			return true;
	return false;
}

Boolean TEventFinder::canAddCondition()
{
	return (v_num < MAX_CONDS) ? true : false;
}

void TEventFinder::removeCondition(int i)
{
	if (i < 0 || i >= v_num)
		return;
	int j;
	for(j = v_num - 1; j > i; j--)
	{
		v[j-1].group = v[j].group;
		v[j-1].value = v[j].value;
		vt[j-1] = vt[j].c_str();
	}
	v_num--;
	for(j = 0; j < v_num; j++)
	{
		v[j].text = vt[j].c_str();
	}
}

void TEventFinder::addCondition(int inGroup, int inValue)
{
	v[v_num].group = inGroup;
	v[v_num].value = inValue;
	v_num++;
}

void TEventFinder::addConditionText(const char * szText)
{
	v[v_num].group = 10;
	vt[v_num] = szText;
	v[v_num].text = vt[v_num].c_str();
	v_num++;
}


//===========================================================================================
//
//===========================================================================================

void TEventFinder::Calculate(CLocation &L, int inYear, int inCount)
{
	int i, j, k, c;
	TFinderBuffer buf;
	TString str;
	VAISNAVADAY * pd;
//	VCTIME vcFrom, vcTo;
//	Boolean next_day = false;
//	DWORD dwDateNote;

	// update data

	if (canTest() == false)
	{
		printf("Please specify at least one condition for day.\n");
		return;
	}

	printf ("Event Finder in pogress...\n");

	c = 0;

	// 
	for(i = inYear; i < inYear + inCount; i++)
	{
		for(j = 1; j < 13; j++)
		{

			// vypocet dni pre datum
			buf.CalculateFindCalendar(i, j, L);

			// prechadzanie cez datumy
			for(k = buf.GetStartIndex(); k <= buf.GetUpperBound(); k++)
			{
				pd = &(buf.m_rData[k]);

				if (pd->date.month != j)
					continue;

				if ((pd->date.month==j) && Test(pd))
				{
					FormatCalendarDayText(pd, str);
					printf(str.c_str());
					printf("-------------------------------------------------------------------------\n");
					c++;
				}

			}
		}
	}

	if (c < 1)
	{
		printf("-------------------------- < no results > -------------------------\n");
	}
	else
	{
		printf("Found %d days.\n", c);
	}

}

void PrintHead(const char *);

void PrintEventFinderClasses()
{
	int i, m;
	m = sizeof(g_egroup)/sizeof(TEventClass);
	for(i = 0; i < m; i++)
	{
		printf( "     %d - %s\n", g_egroup[i].group, g_egroup[i].text);
	}
}

void PrintEventFinderValues(int nClass)
{
	int i, m;
	m = sizeof(g_eval)/sizeof(TEventValue);
	for(i = 0; i < m; i++)
	{
		if (g_eval[i].group == nClass)
			printf("     %d -- %s\n", g_eval[i].value, g_eval[i].text);
	}
}

int EnterNumber(const char *, int &);
int EnterString(const char *, TString &);
int EnterChoice(const char *, const char *, int &);
int getchoice();
int EnterLocationEx(CLocation &);
int DlgMasaList(int &, int &);

void DlgAddFinderCondition(TEventFinder &F)
{
	TEventValue ev;
	TString str;
	printf("\nClasses:\n");
	PrintEventFinderClasses();
	if (EnterNumber("Enter class of event:", ev.group))
	{
		if (ev.group == 10)
		{
			if (EnterString("Find text:", str))
			{
				F.addConditionText(str.c_str());
			}
		}
		else
		{
			PrintEventFinderValues(ev.group);
			if (EnterNumber("Enter ID of value:", ev.value))
			{
				F.addCondition(ev.group, ev.value);
			}
		}
	}
}

void DlgEventFinder()
{
	CLocation loc;
	int nYear, nCount;
	TEventFinder F;
	int n;
	VCTIME vc;
	vc.Today();
	nYear = vc.year;
	nCount = 3;
	loc = gLastLocation;

	PrintHead("EVENT FINDER");

	while(1)
	{
		printf("\n----------------------------------------------------------------------------");
		printf("\nConditions ");
		if (F.b_and == true)
			printf("(with operator AND):\n");
		else
			printf("(with operator OR):\n");
		for(n = 0; n < F.v_num; n++)
		{
			printf("%2d  %s => %s\n", n, F.v[n].getClassText(), F.v[n].getValueText());
		}

		printf("\nLocation:\n%s\n", loc.getFullName());

		printf("\nTime Period: %d - %d (including)\n", nYear, nYear + nCount - 1);

		printf("\nMenu:\n");
		if (F.canAddCondition())
			printf("A-add condition | ");
		printf("R-remove condition | L-set location | T-set time | C-calculate\nO-set operator E-exit\n\n");

		switch(getchoice())
		{
		case 'a':case 'A':
			if (F.canAddCondition())
			{
				DlgAddFinderCondition(F);
			}
			break;
		case 'r':case 'R':
			if (EnterNumber("Enter number of condition:", n))
			{
				F.removeCondition(n);
			}
			break;
		case 'l':case 'L':
			EnterLocationEx(loc);
			break;
		case 't':case 'T':
			DlgMasaList(nYear, nCount);
			break;
		case 'c':case 'C':
			F.Calculate(loc, nYear, nCount);
			break;
		case 'o':case 'O':
			if(EnterChoice("Enter applied operator:", "1-AND 2-OR :", n))
			{
				if (n=='2') F.b_and = false;
				else F.b_and = true;
			}
			break;
		case 'e':case 'E': case 'x':case 'X':case 'q':case 'Q':
			printf("Exit from Event Finder, back to main menu.\n");
			return;
		default:
			break;
		}
	}
}

const char * TEventValue::getClassText()
{
	int i, m;
	m = sizeof(g_egroup)/sizeof(TEventClass);
	for(i = 0; i < m; i++)
	{
		if (g_egroup[i].group == group)
		{
			return g_egroup[i].text;
		}
	}
	return "<undefined>";
}

const char * TEventValue::getValueText()
{
	int i, m;
	m = sizeof(g_eval)/sizeof(TEventValue);
	if (group == 10)
		return text;
	for(i = 0; i < m; i++)
	{
		if (g_eval[i].group == group && g_eval[i].value == value)
			return g_eval[i].text;
	}
	return "<undefined>";

}
