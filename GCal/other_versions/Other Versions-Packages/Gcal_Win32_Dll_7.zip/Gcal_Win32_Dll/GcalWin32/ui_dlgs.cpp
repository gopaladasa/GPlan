#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

#include "astro.h"
#include "TFile.h"
#include "avc.h"
#include "TTimeZone.h"
#include "TCountry.h"

const char * GetAyanamsaName(int);
const char * GetSankMethodName(int i);
int SetAyanamsaType(int);
int GetAyanamsaType();
int GetSankrantiType();
int SetSankrantiType(int);
int CalcMasaList(TResultMasaList &, CLocation &, int, int);
int FormatMasaListText(TResultMasaList &, TString &);
int AvcComboMasaToMasa(int);
void backprintf(const char *);
Boolean GCalApp_InitLanguageOutputFromFile(const char * pszFile);

extern TLangFileList gLangList;
extern TString gCustomEventTexts[360];
extern CLocation gMyLocation;

void PrintTitle(const char *c)
{
	printf("\n---------------------------------------------------------------\n");
	printf("--    %s\n", c);
	printf("---------------------------------------------------------------\n\n");
}

int isfinish(int a)
{
	return ((a==0) || (a==10));
}

#ifdef _WIN32
int strcasencmp(const char *a, const char *b, int len)
{
	int i;
	for(i = 0; i < len && !isfinish(a[i]) && !isfinish(b[i]); i++)
	{
		if (tolower(a[i]) < tolower(b[i]))
			return -1;
		if (tolower(a[i]) > tolower(b[i]))
			return 1;
	}
	return 0;
}
#endif

int getchoice()
{
     char sz[12];
     
     fgets(sz, 10, stdin);
     
     return sz[0];
}

int EnterChoice(const char *title, const char *sc, int &val)
{
     int i;
	 if (title != NULL)
		 PrintTitle(title);
     printf(sc);
     i = getchoice();
     if (i ==0)
          return 0;
     val = i;
     return 1;
}

int EnterString(const char * title, TString &s)
{
     char sz[80];
     printf(title);
     fgets(sz, 70, stdin);
     sz[70] = 0;
	 for(int a = 0; sz[a] > 31; a++)
	 sz[a] = 0;
     if (strlen(sz)==0)
          return 0;
     s = sz;
     return 1;
}


int EnterNumber(const char * pc, int &num)
{
	char sz[32];
	printf(pc);
	fgets(sz, 30, stdin);
	if (strlen(sz) == 0)
		return 0;
	num = atoi(sz);
	return 1;
}

int EnterDateHour(VCTIME &vc)
{
	int a, b;
	PrintTitle("Enter Date and Hour");
	EnterNumber("Enter Day:", vc.day);
	EnterNumber("Enter Month:", vc.month);
	EnterNumber("Enter Year:", vc.year);
	EnterNumber("Enter Hour:", a);
	EnterNumber("Enter Minute:", b);
	vc.shour = a*(1/24.0) + b*(1/1440.0);

	return 1;
}

int EnterDate(VCTIME &vc)
{
	PrintTitle("Enter Date");
	EnterNumber("Enter Day:", vc.day);
	EnterNumber("Enter Month:", vc.month);
	EnterNumber("Enter Year:", vc.year);
	vc.shour = 0.5;

	return 1;
}

int AvcGetEarthPosFromString(const char *, bool , double &);

int EnterLatitude(double &lat)
{
	TString str;
	while (EnterString("Latitude:", str))
	{
		if (str.GetLength() < 1)
			break;
		if (AvcGetEarthPosFromString(str.c_str(), true, lat))
		{
			return 1;
		}
		printf("Invalid format for latitude. Enter empty string for exit.\nCorrect latitude is like 12N00, 13S50.\n");
	}
	return 0;
}

int EnterLongitude(double &lon)
{
	TString str;
	while (EnterString("Longitude:", str))
	{
		if (str.GetLength() < 1)
			break;
		if (AvcGetEarthPosFromString(str.c_str(), false, lon))
		{
			return 1;
		}
		printf("Invalid format for longitude. Enter empty string for exit. Correct longitude is like 12E00, 13W50.\n");
	}
	return 0;
}

int EnterTimezone(const char * s)
{
	TString str;
	int ntz[16];
	int ntzc = 0;
	int stz;

try_again:
	while (EnterString(s, str))
	{
		const char * mb = str.c_str();
		const char * ms = strchr(mb, '/');
		if (ms == NULL)
			return -1;
		int nb = strlen(mb) - strlen(ms);
		int ns = strlen(ms) - 1;
		ms++;
		const char * fb, *fs;

		for(int i = 0; i < TTimeZone::GetTimeZoneCount(); i++)
		{
			fb = TTimeZone::GetTimeZoneName(i);
			fs = strchr(fb, '/');
			if (fs)
			{
				fs++;
				if (strcasencmp(mb, fb, nb) == 0 && strcasencmp(ms, fs, ns)==0)
				{
					if (ntzc<16)
					{
						ntz[ntzc] = i;
						ntzc++;
					}
				}
			}
		}
		if (ntzc == 0)
		{
			printf("Timezone not found.\n");
		}
		else if (ntzc==1)
		{
			printf("\nSelected timezone is %s %s.\n", AvcGetTextTimeZone(TTimeZone::gzone[ntz[0]].tzone),
				TTimeZone::gzone[ntz[0]].name);
			return ntz[0];
		}
		else
		{
			for(int a = 0; a < ntzc; a++)
			{
				printf("[%3d]   %s %s.\n", a, AvcGetTextTimeZone(TTimeZone::gzone[ntz[a]].tzone),
					TTimeZone::gzone[ntz[a]].name);

			}
			printf("[ 99]   try another string\n\n");
			if (EnterNumber("Type ID of timezone to select:", stz))
			{
				if (stz >= 0 && stz < ntzc)
					return ntz[stz];
				else
					goto try_again;
			}
			else
			{
				return -1;
			}
		}
	}
	return -1;
}

char * AvcGetTextTimeZone(double);

//============================================================================
// 
//============================================================================

int EnterTimezoneEx(double lat, double lon, int &dst_id)
{
	int n, m = TTimeZone::GetTimeZoneCount(), c;
	int a = 0;

	for(n = 1; n < m; n++)
	{
		TTimeZone & T = TTimeZone::gzone[n];
		if (T.latA < lat && lat < T.latB && T.lonA < lon && lon < T.lonB)
		{
			printf("%d %-10s %s\n", n, AvcGetTextTimeZone(TTimeZone::gzone[n].tzone),
				TTimeZone::gzone[n].name);
			a++;
		}
	}
	if (a == 0)
	{
		printf("  0  %-10s <undefined>\n", AvcGetTextTimeZone(lon/15.0));
	}

	if (EnterNumber("Select timezone:", c))
	{
		dst_id = n;
		return 1;
	}

	return 0;
}



void DlgSelectLangOutput()
{
	int i;
	TLangFileInfo * p = gLangList.list;
	
	printf("Select Langugage for output\n");
	printf("0 - English\n");
	i = 0;
	while(p)
	{
		printf("%d - %s\n", i++, p->m_strLang.c_str());
		p = p->next;
	}

     printf("Type the number of language or type empty line for exit\n>\n");
     if(getchoice() >= 0)
     {
          p = gLangList.list;
          while(p && i>0)
          {
               i--;
               p = p->next;
          }
          if (i == 0 && p)
          {
               if (p == gLangList.list)
			   {
		   			InitGlobalStrings();
			   }
			   else
			   {
				   // here sets language
				   if (GCalApp_InitLanguageOutputFromFile(p->m_strFile.c_str()) == true)
				   {
					   printf("Language set success.\n");
				   }
				   else
				   {
					   printf("Language not set.\n");
				   }
			   }
          }
     }

     return;
}

void DlgSetAyanamsaType(void)
{
	int i;
	PrintTitle("Setting of Ayanamsa and Sankranti Method");

    printf("Ayanamsa systems:\n");
	printf("1 - %s\n", GetAyanamsaName(0));
	printf("2 - %s\n", GetAyanamsaName(1));
	printf("3 - %s\n", GetAyanamsaName(2));
	printf("4 - %s\n", GetAyanamsaName(3));

    printf("\n\nSankranti Methods:\n");
	printf("a - %s\n", GetSankMethodName(0));
	printf("b - %s\n", GetSankMethodName(1));
	printf("c - %s\n", GetSankMethodName(2));
	printf("d - %s\n", GetSankMethodName(3));

     while(1)
     {
          printf("\n\nType \'x\' for exit, or choice which you want to set:");
          switch(i = getchoice())
          {
          case 1: case 2:
          case 3: case 4:
               SetAyanamsaType(i - '1');
               printf("Set ayanamsa system %s.\n", GetAyanamsaName(i-'1'));
               break;
          case 'a': case 'b': case 'c': case 'd':
               SetSankrantiType(i - 'a');
               printf("Set sanakranti system %s.\n", GetSankMethodName(i-'1'));
               break;
          case 'x':
               return;
          default:
               break;
          }
     }

	return;
}


int WriteObservedEventsText(TFile &f)
{
	int n;
	TString str, str2, str3;
	char szTemp[256];
	int nTemp = 0;
	int ct = 0;
	const char * pSrc;
	int nBrLevel = 0;

	for(int i = 0; i < 360; i++)
	{
		n = 0;
		if (gstr[200+i].IsEmpty() == false)
		{
			pSrc = gstr[200 + i];

			for(ct = 0; pSrc[ct]; ct++)
			{
				// beginning of note
				if (pSrc[ct] == '[')
				{
					nBrLevel++;
				}

				if (pSrc[ct] == '#')
				{
					if (nTemp >= 256)
						szTemp[255] = 0;
					else
						szTemp[nTemp] = 0;
					str.Format("%s\t%s, %s Paksa, %s Masa", szTemp, GetTithiName(i % 30), GetPaksaName((i/15)%2), GetMasaName(i/30));
					f.WriteString(str.c_str());
					nTemp = 0;
				}
				else if (nBrLevel < 1)
				{
					if (nTemp < 256)
					{
						szTemp[nTemp] = pSrc[ct];
						nTemp++;
					}
				}

				// end of note
				if (pSrc[ct] == ']')
				{
					nBrLevel--;
				}
			}

			if (nTemp > 0)
			{
				if (nTemp >= 256)
					szTemp[255] = 0;
				else
					szTemp[nTemp] = 0;
				str.Format("%s\t%s, %s Paksa, %s Masa", szTemp, GetTithiName(i % 30), GetPaksaName((i/15)%2), GetMasaName(i/30));
				f.WriteString(str.c_str());
				nTemp = 0;
			}

		}
	}

	f.WriteString("Sri Krsna Janmastami\tAstami, Krsna Paksa, Hrsikesa Masa");
	f.WriteString("Govardhana Puja, Go Puja, Go Krda.\tPratipat, Gaura Paksa, Damodara Masa");
	f.WriteString("Nandotsava.\t(a day after Sri Krsna Janmastami)");
	f.WriteString("Srila Prabhupada -- Appearance\t(a day after Sri Krsna Janmastami)");
	f.WriteString("Ratha Yatra\tDvitiya, Gaura Paksa, Vamana Masa");
	f.WriteString("Gaura Purnima\tPurnima, Gaura Paksa, Govinda Masa");
	f.WriteString("Jagannatha Misra festival\t(a day after Gaura Purnima)");
	f.WriteString("Hera Pancami\t(4 days after Ratha yatra)");
	f.WriteString("Return Ratha yatra\t(8 days after Ratha yatra festival)");
	f.WriteString("Gundica Marjana\t(a day before Ratha Yatra festival");
	f.WriteString("Ganga Sagara Mela\t(Makara Sankranti)");
	f.WriteString("Tulasi Jala Dan begins\t(Mesha Sankranti)");
	f.WriteString("Tulasi Jala Dan ends\t(a day before Vrsabha Sankranti)");
	f.WriteString("Rama Navami\tNavami, Gaura Paksa, Visnu Masa");

	return 1;
}

int WriteObservedEventsXml(TFile &f)
{
	TString str, str2, str3;
	int n, i;
	f.WriteString("<xml>\n");
	for(i = 0; i < 360; i++)
	{
		n = 0;
		if (gstr[200+i].IsEmpty() == false)
		{
			str2 = gstr[200 + i];
			n = str2.Find("#");
			while(n >= 0)
			{
				str2.Left(n, str3);
				str.Format("\t<event name=\"%s\" tithi=\"%s\" paksa=\"%s\" masa=\"%s\" />\n", str3.c_str(), GetTithiName(i % 30), GetPaksaName((i/15)%2), GetMasaName(i/30));
				str2.Delete(0, n+1);
				f.WriteString(str);
				n = str2.Find("#");
			}
			if (str2.IsEmpty() == false)
			{
				str.Format("\t<event name=\"%s\" tithi=\"%s\" paksa=\"%s\" masa=\"%s\" />\n", str2.c_str(), GetTithiName(i % 30), GetPaksaName((i/15)%2), GetMasaName(i/30));
				f.WriteString(str);
			}
		}
	}
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_JANMASTAMI));
	f.WriteString("\" tithi=\"Astami\" paksa=\"Krsna\" masa=\"Hrsikesa\" />\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_GOVARDHANPUJA));
	f.WriteString("\" tithi=\"Pratipat\" paksa=\"Gaura\" masa=\"Damodara\" />\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_RATHAYATRA));
	f.WriteString("\" tithi=\"Dvitiya\" paksa=\"Gaura\" masa=\"Vamana\" />\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_GAURAPURNIMA));
	f.WriteString("\" tithi=\"Purnima\" paksa=\"Gaura\" masa=\"Govinda\" />\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_NANDAUTSAVA));
	f.WriteString("\" depends=\"Sri Krsna Janmastami\" rel=\"+1\"/>\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_PRABHAPP));
	f.WriteString("\" depends=\"Sri Krsna Janmastami\" rel=\"+1\"/>\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_MISRAFESTIVAL));
	f.WriteString("\" depends=\"Gaura Purnima\" rel=\"+1\"/>\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_HERAPANCAMI));
	f.WriteString("\" depends=\"Ratha Yatra\" rel=\"+4\"/>\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_RETURNRATHA));
	f.WriteString("\" depends=\"Ratha Yatra\" rel=\"+8\"/>\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_GUNDICAMARJANA));
	f.WriteString("\" depends=\"Ratha Yatra\" rel=\"-1\"/>\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(gstr[78]);
	f.WriteString("\" sankranti=\"Makara\" rel=\"0\"/>\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(gstr[79]);
	f.WriteString("\" sankranti=\"Mesha\" rel=\"0\"/>\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(gstr[80]);
	f.WriteString("\" sankranti=\"Vrsabha\" rel=\"-1\"/>\n");
	f.WriteString("\t<event name=\"");
	f.WriteString(GetSpecFestivalName(SPEC_RAMANAVAMI));
	f.WriteString("\" tithi=\"Navami\" paksa=\"Gaura\" masa=\"Visnu\" />\n");
	f.WriteString("</xml>\n");

	return 1;
}

void DlgObservedEventsExport()
{
     TString str;
     int fformat = 0;
     
     if (EnterChoice("Choose file format:", "t-text\nx-xml\n", fformat)
          && EnterString("Enter file name:", str))
     {
		TFile f;

		if (f.Open(str.c_str(), "w") == true)
		{
			if (fformat == 't')
				WriteObservedEventsText(f);
			else if (fformat == 'x')
				WriteObservedEventsXml(f);
			f.Close();
		}
	}
}



int DlgMasaList(int &nYear, int &nCount) 
{
	int m_Year, m_Count;
	TString str;
	
	PrintTitle("Enter starting year and the number of years calculated");
	if (EnterNumber("Enter start year:", m_Year)
		&& EnterNumber("Enter count of years:", m_Count))
	{
		if (m_Count > 20)
			m_Count = 20;
		if (m_Year + m_Count > 3999)
		{
			m_Count = 4000 - m_Year;
		}

		nYear = m_Year;
		nCount = m_Count;
	
		return 1;
	}

	return 0;
}

int EnterLocation(CLocation &loc)
{
	if (EnterString("Enter location name:", loc.m_strCity)
		&& EnterString("Country of location:", loc.m_strCountry))
	{
		if (EnterLatitude(loc.m_fLatitude) && EnterLongitude(loc.m_fLongitude))
		{
			if (EnterTimezoneEx(loc.m_fLatitude, loc.m_fLongitude, loc.m_nDST))
			{
				if (loc.m_nDST == 0)
					loc.m_fTimezone = floor(loc.m_fLongitude/15.0);
				return 1;
			}
		}
	}

	return 0;
}

int DlgGetLocationEx_CreateLocation(CLocation &loc) 
{
	// TODO: Add your control notification handler code here
	if (EnterLocation(loc))
	{
		CLocation * pl = new CLocation;
		*pl = loc;
		theLocs.AddTail(pl);
		printf("Location added succesfully.\n");
		return 1;
	}

	return 0;
}

int PageBreak()
{
	int ic;
	static int i = 0;
	if (i > 25)
	{
		printf("- - - - - - - - - - - - - - - - - - - ENTER-continue, C-cancel listing - - - - ");
		ic = getchoice();
		if ( tolower(ic) == 'c')
		{
			i = 0;
			return 1;
		}
		i = 0;
	}
	i++;
	return 0;
}

int  DlgGetLocationEx_ListCountry()
{
	for(int i = 0; i< TCountry::GetCountryCount(); i++)
	{
		UInt16 w = TCountry::gcountries[i].code;
		printf("%3d  %c%c  %s\n", i, char((w & 0xff00)>>8), char(w&0xff), TCountry::gcountries[i].pszName);
		if (PageBreak()) break;
	}

	return 1;
}

void DlgGetLocationEx_ListCity()
{
	int n;
	CLocation * pos;

	pos = theLocs.GetHeadPosition();
	n = 0;
	while(pos)
	{
		printf("%3d %-25s | %-15s  %s %s\n", n++, pos->m_strCity.c_str(), 
			pos->m_strCountry.c_str(), AvcGetTextLatitude(pos->m_fLatitude), 
			AvcGetTextLongitude(pos->m_fLongitude));
		pos = pos->next;
		if (PageBreak()) break;
	}
}

void DlgGetLocationEx_ResetList() 
{
	printf("Do you want to reset list? (y/n)");
	if (getchar() == 'y')
	{
		theLocs.RemoveAll();
		theLocs.InitInternal();
	}
}

int DlgGetLocationEx_Find(CLocation &loc)
{
	CLocation * pos;
	TString str;
	int n, len;
	CLocation * ref[10];
	
_try_again:
	if (EnterString("Enter few starting letters of location name:", str))
	{
		pos = theLocs.GetHeadPosition();
		n = 0;
		len = str.GetLength();
		while(pos && n<10)
		{
			if (strcasencmp(pos->m_strCity.c_str(), str.c_str(), len) == 0)
			{
				if (n < 10)
				{
					ref[n] = pos;
					printf("[%d] %-30s     %s %s\n", n, pos->m_strCity.c_str(),
						AvcGetTextLatitude(pos->m_fLatitude),
						AvcGetTextLongitude(pos->m_fLongitude));
					n++;
				}
			}
			pos = pos->next;
		}
		printf("[10] do another searching\n");
		if (n == 0)
		{
			printf("not found.\n");
		}
		else if (n == 1)
		{
			loc = *(ref[0]);
			return 1;
		}
		else
		{
			len = 0;
			if(EnterNumber("Select city:", len))
			{
				if (len >= 0 && len < n)
				{
					loc = *ref[len];
					return 1;
				}
			}
			if (len != 10)
				return 0;
			goto _try_again;
		}
	}
	return 0;
}

//============================================================================
// 
//============================================================================

void PrintDSTInfo()
{
	int i;
	int a[8];
	TString str, ret;


	i = EnterTimezone("Enter time zone string:");
	
	if (i < 0 || i >= TTimeZone::GetTimeZoneCount())
		return;

	UInt32 dw = TTimeZone::gzone[i].val;


	if (dw == 0)
	{
		ret = gstr[807];
	}
	else
	{
		TTimeZone::ExpandVal(dw, a);

		ret = gstr[808];
		// pre datumovy den
		if (a[1] == 1)
		{

			str.Format("\nsince %s %s ", gstr[a[2] + 810].c_str(), gstr[a[0] + 794].c_str());
			//SetDlgItemText(IDC_STATIC_DST_INFO1, str);
		}
		else
		{
			// pre tyzdenny den
			str.Format("\nsince %s %s %s ", gstr[a[2] + 781].c_str(), gstr[a[3] + 787].c_str(), gstr[a[0] + 794].c_str());
			//SetDlgItemText(IDC_STATIC_DST_INFO1, str);
		}
		ret += str;

		if (a[5] == 1)
		{
			str.Format("\nto %s %s", gstr[810 + a[6]].c_str(), gstr[a[4] + 794].c_str());
			//SetDlgItemText(IDC_STATIC_DST_INFO2, str);
		}
		else
		{
			// pre tyzdenny den
			str.Format("\nto %s %s %s", gstr[a[6] + 781].c_str(), gstr[a[7] + 787].c_str(), gstr[a[4] + 794].c_str());
			//SetDlgItemText(IDC_STATIC_DST_INFO2, str);
		}
		ret += str;
	}

	printf(ret);
	printf("\n");
}

int EnterLocationEx(CLocation &loc) 
{
	int c;
	int ret = 0;

	PrintTitle("Enter Location");
	
	while (EnterChoice(NULL, "f - find city\na - enter another location\n"
		"c - create location\n1 - countries\n2 - cities\n3 - timezone info\n"
		"[other] - exit\n\n>", c))
	{
		switch(c)
		{
		case '1':
			DlgGetLocationEx_ListCountry();
			break;
		case '2':
			DlgGetLocationEx_ListCity();
			break;
		case 'f':
			ret = DlgGetLocationEx_Find(loc);
			if (ret == 1)
			{
				printf("Current Location: %s\n\n", loc.getFullName());
				return 1;
			}
			break;
		case 'c':
			ret = DlgGetLocationEx_CreateLocation(loc);
			break;
		case '3':
			PrintDSTInfo();
			break;
		case 'a':
			ret = EnterLocation(loc);
		default:
			return ret;
		}
		printf("Current Location: %s\n\n", loc.getFullName());
	}
	return 0;
}

int DlgGetEventSpec(UInt32 &m_fOptions) 
{
	int i;

	PrintTitle("Enter Specification for Events");

	printf("Calculate sunrise, sunset, etc.. ? (y/n/c)");
	i = getchoice(); if (i=='c') return 0;
	if (i=='y') m_fOptions |= CCE_SUN;
		
	printf("Calculate tithis ? (y/n/c)");
	i = getchoice(); if (i=='c') return 0;
	if (i=='y') m_fOptions |= CCE_TIT;

	printf("Calculate naksatras ? (y/n/c)");
	i = getchoice(); if (i=='c') return 0;
	if (i=='y') m_fOptions |= CCE_NAK;

	printf("Calculate sankrantis ? (y/n/c)");
	i = getchoice(); if (i=='c') return 0;
	if (i=='y') m_fOptions |= CCE_SNK;

	printf("Calculate conjunctions ? (y/n/c)");
	i = getchoice(); if (i=='c') return 0; 
	if (i=='y') m_fOptions |= CCE_CNJ;

	printf("Sort? (y/n/c)");
	i = getchoice(); if (i=='c') return 0; 
	if (i=='y') m_fOptions |= CCE_SORT;

	return 1;
}

int DlgGetEndDate(VCTIME vc_start, VCTIME &vc_end)
{
	TString s;
	const char * pc;
	int n, type, len;
	vc_end = vc_start;
	vc_end.year ++;
	PrintTitle("Enter period for calculation");
	printf("examples: 20d = 20 days, 3w = 3 weeks, 1y = 1 Year\nempty string for accept, c - cancel\n");

	while(EnterString(">", s))
	{
		if (strlen(s.c_str()) == 0)
			return 1;
		if (strncmp(s.c_str(), "c", 1) == 0)
			return 0;
		n = 0;
		type = 0;
		pc = s.c_str();
		len = strlen(pc);
		for(int a = 0; a < len; a++)
		{
			if (isdigit(pc[a]))
				n = n*10 + (pc[a] - '0');
			else
			{
			switch(pc[a])
			{
				case 'd': case 'D':
					type = 0;
					break;
				case 'w': case 'W':
					type = 1;
					break;
				case 'm': case 'M':
					type = 2;
					break;
				case 'y': case 'Y':
					type = 3;
					break;
			}
			}
		}
		vc_end = vc_start;
		switch(type)
		{
		case 0:
			vc_end += n;
			break;
		case 1:
			vc_end += n*7;
			break;
		case 2:
			vc_end.month += n;
			while(vc_end.month > 12)
			{
				vc_end.month -= 12;
				vc_end.year ++;
			}
			break;
		case 3:
			vc_end.year += n;
			break;
		}
		
		printf("Date Range %d %s %d - %d %s %d\n",
			vc_start.day, AvcGetMonthAbr(vc_start.month), vc_start.year,
			vc_end.day, AvcGetMonthAbr(vc_end.month), vc_end.year);
	}
	
	return 1;
}

int DlgEventsTypeOfEvent()
{
	int c;

	EnterChoice("Specify the type of entering date", "1-gaurabda date\n2-gregorian date\n", c);
	
	return c;
}

int DlgEventsGaubdTM(VATIME &va)
{
	int i = 0, n;
	TString str;

	PrintTitle("Select Tithi and Masa");
	printf("%s Paksa       | %s Paksa\n", GetPaksaName(0), GetPaksaName(1));
	printf("--------------------------------------------\n");
	for(n = 0; n < 15; n++)
	{
		printf("%d - %s    | %d -  %s\n", n, GetTithiName(n), n+15, GetTithiName(n+15));
	}

	printf("--------------------------------------------\n");
	for(n = 0; n < 6; n++)
	{
		printf("%d - %s Masa    |   %d - %s Masa\n",
			n, GetMasaName(AvcComboMasaToMasa(n)),
			n + 6, GetMasaName(AvcComboMasaToMasa(n+6)));
	}
	printf("--------------------------------------------\n");

	if (EnterNumber("Tithi:", va.tithi) && EnterNumber("Masa:", va.masa))
		return 1;

	return 0;
}



void DlgCustomEventDialog_AddEvent() 
{
	CCustomEvent ce;
	CLocation loc;
	VATIME va;
	VCTIME vc;
	TString str;
	EARTHDATA earth;
	int nTithi, nMasa, n;

	switch(DlgEventsTypeOfEvent())
	{
	case '1':
		if (DlgEventsGaubdTM(va))
		{
			nTithi = va.tithi;
			nMasa  = va.masa;
		}
		// gaurabda date
		break;
	case '2':
		if (EnterLocation(loc))
		{
			if (EnterDateHour(vc))
			{
				VCTIME  vc;
				DAYDATA day;

				earth = (EARTHDATA)loc;
				DayCalc(vc, earth, day);
				nMasa = MasaCalc(vc, day, earth, day.nGaurabdaYear);
				nTithi = day.nTithi;
			}
		}
		// gregorian date
		break;
	}

	// zadava text eventu
	if (!EnterString("Enter name of event:", str))
		return;

	ce.nMasa = nMasa;
	ce.nTithi = nTithi;
	ce.strText = str.c_str();

	CCustomEvent * pce = gCustomEventList.add();
	if (pce)
		*pce = ce;

	// vklada do global custom events
	n = nMasa*30 + nTithi;
	if (n >= 0 && n < 360)
	{
		if (gCustomEventTexts[n].IsEmpty() == true)
		{
			gCustomEventTexts[n] = ce.strText;
		}
		else
		{
			gCustomEventTexts[n] += "#";
			gCustomEventTexts[n] += ce.strText;
		}
	}
	else
	{
		printf("Unable to add custom event on incorrect date. (Tithi=%d, Masa=%d)\n", nTithi, nMasa);
	}
}

void PrintCustomEvents()
{
	CCustomEvent * pos;
	pos = gCustomEventList.list;
	printf("TITHI     PAKSA  MASA           TEXT\n--------------------------------------------------\n");
	while(pos)
	{
		printf("%-10s%-7s%-15s%s\n", GetTithiName(pos->nTithi)
			, GetPaksaName(pos->nTithi / 15)
			, GetMasaName(pos->nMasa)
			, pos->strText);
		pos = pos->next;
	}
}

void DlgCustomEvent()
{
	PrintTitle("Custom Events");
	int c;

	PrintCustomEvents();

	while(EnterChoice(NULL, "A-add event\nE-exit\n>", c))
	{
		if (c == 'a')
			DlgCustomEventDialog_AddEvent();
		else if (c == 'q')
		{
			printf ("Exit from custom event manager to the main menu.\n");
			return;
		}
		PrintCustomEvents();
	}
}

int GetShowSetCount();
int GetShowSetVal(int);
char * GetShowSetName(int);
void SetShowSetVal(int,int);

void PrintShowSet(void)
{
	printf("\n");
	for(int i = 0; i < GetShowSetCount(); i++)
	{
		printf("%3d [%c] %s\n", i, (GetShowSetVal(i) ? '+' : ' '), GetShowSetName(i));
	}
	printf("\n");
}

void DlgShowSet()
{
	TString str;
	const char * p;
	int n;
	PrintTitle("Set Display Settings fo Calendar");
	printf("\nFor choice just type +15 for setting property number 15 to TRUE, or type -10 for setting property number 10 to FALSE, or press ENTER for exit.\n\n");
	PrintShowSet();
	while(EnterString("Enter choice:", str))
	{
		p = str.c_str();
		if (p[0] == '+')
		{
			n = atoi(p+1);
			if (n >= 0 && n < GetShowSetCount())
				SetShowSetVal(n, 1);
		}
		else if (p[0] == '-')
		{
			n = atoi(p+1);
			if (n >= 0 && n < GetShowSetCount())
				SetShowSetVal(n, 0);
		}
		else
			return;
		PrintShowSet();

	}
}


void DlgExport()
{
	int c;
	TString str;
	PrintTitle("Export Data");

	while(EnterChoice(NULL, "1 - export default observed events\n2 - export locations (as XML)\n", c))
	{
		switch(c)
		{
		case '1':
			DlgObservedEventsExport();
			break;
		case '2':
			if (EnterString("Enter file name:", str))
			{
				if (theLocs.SaveAs(str.c_str(), 1) == false)
				{
					printf("Export locations failed.\n");
				}
			}
			break;
		}
	}
}

void DlgSetMy()
{
	EnterLocationEx(gMyLocation);
	printf("My Location is %s\n", gMyLocation.getFullName());
}


void PrintTimeZones()
{
	for(int i = 0; i < TTimeZone::GetTimeZoneCount(); i++)
	{
		printf("%3d %7s  %s\n", i, AvcGetTextTimeZone(TTimeZone::gzone[i].tzone),
			TTimeZone::GetTimeZoneName(i));
		if (PageBreak()) break;
	}
}

//===========================================================================================
//
//===========================================================================================

void DlgLocations()
{
	int c;
	int ret = 0;
	CLocation loc;

	PrintTitle("Enter Location");
	
	while (EnterChoice(NULL, "f - find city\n"
		"c - create location\n1 - list countries\n2 - list cities\n3 - list timezones\n"
		"4 - timezone info\n"
		"[other] - exit\n\n>", c))
	{
		switch(c)
		{
		case '1':
			DlgGetLocationEx_ListCountry();
			break;
		case '2':
			DlgGetLocationEx_ListCity();
			break;
		case 'f':
			DlgGetLocationEx_Find(loc);
			break;
		case 'c':
			DlgGetLocationEx_CreateLocation(loc);
			break;
		case '3':
			PrintTimeZones();
			break;
		case '4':
			PrintDSTInfo();
			break;
		default:
			return;
		}
		printf("Current Location: %s\n\n", loc.getFullName());
	}

	return;
}

