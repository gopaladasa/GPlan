// TTimeZone.cpp: implementation of the TTimeZone class.
//
//////////////////////////////////////////////////////////////////////

#include "TTimeZone.h"
#include "astro.h"
#include <stdlib.h>
// PORTABLE

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

TTimeZone TTimeZone::gzone[] =
{
  { 0, 0x00000000, "Undefined", 0.0F, 0.0F, 0.0F, 0.0F, 0.0F},
  {60, 0x3050a050, "Europe/Andorra", 1.00F, 42.36F, 42.67F, 1.39F, 1.70F},
  { 0, 0x00000000, "Asia/Dubai", 4.00F, 24.09F, 25.89F, 54.27F, 56.46F},
  { 0, 0x00000000, "Asia/Kabul", 4.50F, 30.05F, 37.57F, 60.97F, 72.42F},
  { 0, 0x00000000, "America/Antigua", -4.00F, 16.93F, 17.22F, -61.98F, -61.68F},
  { 0, 0x00000000, "America/Anguilla", -4.00F, 18.12F, 18.32F, -63.15F, -62.93F},
  {60, 0x3050a050, "Europe/Tirane", 1.00F, 39.56F, 42.46F, 19.34F, 21.09F},
  {60, 0x3050a050, "Asia/Yerevan", 4.00F, 38.80F, 41.35F, 43.65F, 46.65F},
  { 0, 0x00000000, "America/Curacao", -4.00F, 11.95F, 18.13F, -69.20F, -62.88F},
  { 0, 0x00000000, "Africa/Luanda", 1.00F, -17.17F, -5.45F, 12.05F, 22.33F},
  {60, 0x40109050, "Antarctica/McMurdo", 13.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x40109050, "Antarctica/South_Pole", 13.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Antarctica/Rothera", -3.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Antarctica/Palmer", -3.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Antarctica/Mawson", 6.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Antarctica/Davis", 7.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Antarctica/Casey", 8.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Antarctica/Vostok", 6.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Antarctica/DumontDUrville", 10.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Antarctica/Syowa", 3.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "America/Argentina/Buenos_Aires", -3.00F, -40.90F, -27.28F, -64.38F, -55.03F},
  { 0, 0x00000000, "America/Argentina/Cordoba", -3.00F, -35.77F, -28.03F, -64.62F, -58.67F},
  { 0, 0x00000000, "America/Argentina/Jujuy", -3.00F, -24.88F, -22.43F, -66.45F, -63.72F},
  { 0, 0x00000000, "America/Argentina/Tucuman", -3.00F, -27.88F, -25.47F, -66.07F, -54.47F},
  { 0, 0x00000000, "America/Argentina/Catamarca", -3.00F, -28.57F, -28.37F, -65.88F, -65.68F},
  { 0, 0x00000000, "America/Argentina/La_Rioja", -3.00F, -29.53F, -29.33F, -66.95F, -66.75F},
  { 0, 0x00000000, "America/Argentina/San_Juan", -3.00F, -31.64F, -31.44F, -68.64F, -68.44F},
  { 0, 0x00000000, "America/Argentina/Mendoza", -3.00F, -41.25F, -32.78F, -71.40F, -66.25F},
  { 0, 0x00000000, "America/Argentina/Rio_Gallegos", -3.00F, -51.73F, -42.67F, -72.38F, -64.95F},
  { 0, 0x00000000, "America/Argentina/Ushuaia", -3.00F, -54.90F, -54.70F, -68.40F, -68.20F},
  { 0, 0x00000000, "Pacific/Pago_Pago", -11.00F, -14.46F, -14.18F, -170.89F, -170.56F},
  {60, 0x3050a050, "Europe/Vienna", 1.00F, 46.43F, 48.97F, 9.50F, 17.05F},
  {30, 0xa0504050, "Australia/Lord_Howe", 11.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0xa0504050, "Australia/Hobart", 11.00F, -43.07F, -41.05F, 146.07F, 147.42F},
  {60, 0xa0504050, "Australia/Currie", 11.00F, -41.17F, -38.23F, 141.50F, 146.02F},
  {60, 0xa0504050, "Australia/Melbourne", 11.00F, -38.70F, -34.10F, 141.93F, 148.08F},
  {60, 0xa0504050, "Australia/Sydney", 11.00F, -36.33F, -30.22F, 147.92F, 153.02F},
  {60, 0xa0504050, "Australia/Broken_Hill", 10.50F, -32.05F, -23.60F, 133.78F, 141.53F},
  { 0, 0x00000000, "Australia/Brisbane", 10.00F, -30.62F, -23.75F, 148.68F, 153.72F},
  { 0, 0x00000000, "Australia/Lindeman", 10.00F, -23.68F, -16.82F, 139.40F, 150.83F},
  {60, 0xa0504050, "Australia/Adelaide", 10.50F, -37.93F, -32.38F, 135.77F, 140.87F},
  { 0, 0x00000000, "Australia/Darwin", 9.50F, -19.75F, -12.13F, 129.45F, 136.87F},
  {60, 0xa0504050, "Australia/Perth", 9.00F, -35.12F, -15.67F, 113.53F, 128.83F},
  {60, 0xa0504050, "Australia/Eucla", 9.75F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "America/Aruba", -4.00F, 12.42F, 12.62F, -70.13F, -69.93F},
  {60, 0x3050a050, "Europe/Mariehamn", 2.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3050a050, "Asia/Baku", 4.00F, 38.36F, 41.83F, 44.78F, 50.42F},
  {60, 0x3050a050, "Europe/Sarajevo", 1.00F, 42.61F, 45.32F, 15.68F, 19.47F},
  { 0, 0x00000000, "America/Barbados", -4.00F, 12.97F, 13.35F, -59.75F, -59.42F},
  { 0, 0x00000000, "Asia/Dhaka", 6.00F, 20.77F, 26.43F, 88.07F, 92.40F},
  {60, 0x3050a050, "Europe/Brussels", 1.00F, 49.43F, 51.57F, 2.48F, 6.37F},
  { 0, 0x00000000, "Africa/Ouagadougou", 0.00F, 9.78F, 14.54F, -5.27F, 1.89F},
  {60, 0x3050a050, "Europe/Sofia", 2.00F, 41.28F, 44.26F, 22.42F, 28.63F},
  { 0, 0x00000000, "Asia/Bahrain", 3.00F, 25.97F, 26.36F, 50.40F, 50.75F},
  { 0, 0x00000000, "Africa/Bujumbura", 2.00F, -4.23F, -2.48F, 29.02F, 30.65F},
  { 0, 0x00000000, "Africa/Porto-Novo", 1.00F, 6.18F, 11.96F, 1.16F, 3.49F},
  { 0, 0x00000000, "America/St_Barthelemy", 0.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020b010, "Atlantic/Bermuda", -4.00F, 32.28F, 32.48F, -64.78F, -64.58F},
  { 0, 0x00000000, "Asia/Brunei", 8.00F, 4.48F, 4.98F, 114.08F, 115.17F},
  { 0, 0x00000000, "America/La_Paz", -4.00F, -22.20F, -10.70F, -69.18F, -57.67F},
  { 0, 0x00000000, "America/Noronha", -2.00F, -11.01F, -7.37F, -37.18F, -34.71F},
  { 0, 0x00000000, "America/Belem", -3.00F, -4.17F, 0.14F, -52.34F, -43.78F},
  { 0, 0x00000000, "America/Fortaleza", -3.00F, -7.98F, -2.50F, -43.63F, -36.41F},
  { 0, 0x00000000, "America/Recife", -3.00F, -9.00F, -5.10F, -38.25F, -34.73F},
  { 0, 0x00000000, "America/Araguaina", -3.00F, -15.66F, -4.03F, -50.67F, -42.84F},
  { 0, 0x00000000, "America/Maceio", -3.00F, -11.11F, -7.54F, -40.01F, -35.12F},
  { 0, 0x00000000, "America/Bahia", -3.00F, -19.51F, -8.26F, -44.96F, -37.34F},
  {60, 0xa4b02030, "America/Sao_Paulo", -2.00F, -33.62F, -15.35F, -57.19F, -40.17F},
  {60, 0xa4b02030, "America/Campo_Grande", -3.00F, -23.99F, -18.41F, -57.98F, -50.99F},
  {60, 0xa4b02030, "America/Cuiaba", -3.00F, -17.41F, -9.80F, -60.25F, -52.15F},
  { 0, 0x00000000, "America/Porto_Velho", -4.00F, -13.18F, -2.77F, -70.32F, -60.53F},
  { 0, 0x00000000, "America/Boa_Vista", -4.00F, -0.51F, 2.92F, -67.19F, -60.57F},
  { 0, 0x00000000, "America/Manaus", -4.00F, -6.74F, -0.87F, -66.19F, -51.89F},
  { 0, 0x00000000, "America/Eirunepe", -5.00F, -9.04F, -7.51F, -73.00F, -70.25F},
  { 0, 0x00000000, "America/Rio_Branco", -5.00F, -11.12F, -8.74F, -69.36F, -67.64F},
  {60, 0x3020b010, "America/Nassau", -5.00F, 23.00F, 26.97F, -79.07F, -74.88F},
  { 0, 0x00000000, "Asia/Thimphu", 6.00F, 26.75F, 27.68F, 89.18F, 91.57F},
  { 0, 0x00000000, "Africa/Gaborone", 2.00F, -25.88F, -17.72F, 21.62F, 28.88F},
  {60, 0x3050a050, "Europe/Minsk", 2.00F, 51.68F, 55.73F, 23.27F, 32.15F},
  { 0, 0x00000000, "America/Belize", -6.00F, 16.00F, 18.48F, -89.24F, -87.85F},
  {60, 0x3020b010, "America/St_Johns", -3.50F, 47.00F, 49.35F, -59.25F, -52.61F},
  {60, 0x3020b010, "America/Halifax", -4.00F, 43.67F, 45.78F, -66.22F, -61.90F},
  {60, 0x3020b010, "America/Glace_Bay", -4.00F, 45.52F, 46.45F, -62.35F, -61.25F},
  {60, 0x3020b010, "America/Moncton", -4.00F, 44.98F, 46.92F, -67.32F, -62.55F},
  {60, 0x3020b010, "America/Goose_Bay", -4.00F, 50.13F, 53.05F, -67.02F, -63.50F},
  { 0, 0x00000000, "America/Blanc-Sablon", -4.00F, 51.12F, 51.32F, -58.75F, -58.55F},
  {60, 0x3020b010, "America/Montreal", -5.00F, 44.23F, 52.88F, -79.30F, -64.38F},
  {60, 0x3020b010, "America/Toronto", -5.00F, 41.98F, 48.34F, -83.67F, -76.38F},
  {60, 0x3020b010, "America/Nipigon", -5.00F, 48.37F, 49.78F, -86.53F, -80.58F},
  {60, 0x3020b010, "America/Thunder_Bay", -5.00F, 48.30F, 48.50F, -89.42F, -89.22F},
  {60, 0x3020b010, "America/Iqaluit", -5.00F, 62.72F, 63.85F, -92.18F, -68.41F},
  {60, 0x3020b010, "America/Pangnirtung", -5.00F, 66.05F, 70.57F, -68.69F, -65.61F},
  { 0, 0x00000000, "America/Resolute", -5.00F, 67.73F, 68.73F, -115.20F, -95.78F},
  { 0, 0x00000000, "America/Atikokan", -5.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020b010, "America/Rankin_Inlet", -6.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020b010, "America/Winnipeg", -6.00F, 49.00F, 55.84F, -101.10F, -95.96F},
  {60, 0x3020b010, "America/Rainy_River", -6.00F, 48.50F, 48.70F, -93.50F, -93.30F},
  { 0, 0x00000000, "America/Regina", -6.00F, 49.03F, 55.20F, -106.50F, -101.15F},
  { 0, 0x00000000, "America/Swift_Current", -6.00F, 49.55F, 54.23F, -110.03F, -106.45F},
  {60, 0x3020b010, "America/Edmonton", -7.00F, 49.10F, 56.35F, -119.54F, -109.38F},
  {60, 0x3020b010, "America/Cambridge_Bay", -7.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020b010, "America/Yellowknife", -7.00F, 62.36F, 62.56F, -114.45F, -114.25F},
  {60, 0x3020b010, "America/Inuvik", -7.00F, 65.18F, 68.45F, -134.99F, -126.73F},
  { 0, 0x00000000, "America/Dawson_Creek", -7.00F, 55.60F, 58.62F, -121.74F, -117.04F},
  {60, 0x3020b010, "America/Vancouver", -8.00F, 48.27F, 54.88F, -130.42F, -116.40F},
  {60, 0x3020b010, "America/Whitehorse", -8.00F, 60.62F, 60.85F, -137.61F, -134.95F},
  {60, 0x3020b010, "America/Dawson", -8.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Indian/Cocos", 6.50F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Africa/Kinshasa", 1.00F, -6.57F, 4.38F, 12.83F, 22.57F},
  { 0, 0x00000000, "Africa/Lubumbashi", 2.00F, -11.87F, 3.92F, 20.48F, 30.35F},
  { 0, 0x00000000, "Africa/Bangui", 1.00F, 3.43F, 10.38F, 15.05F, 26.60F},
  { 0, 0x00000000, "Africa/Brazzaville", 1.00F, -4.89F, 1.75F, 11.75F, 18.17F},
  {60, 0x3050a050, "Europe/Zurich", 1.00F, 45.73F, 47.85F, 5.89F, 10.40F},
  { 0, 0x00000000, "Africa/Abidjan", 0.00F, 4.32F, 10.59F, -8.52F, -2.70F},
  { 0, 0x00000000, "Pacific/Rarotonga", -10.00F, -21.31F, -21.11F, -159.87F, -159.67F},
  {60, 0x4410a050, "America/Santiago", -3.00F, -53.25F, -18.38F, -73.92F, -68.83F},
  {60, 0x4410a050, "Pacific/Easter", -5.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Africa/Douala", 1.00F, 2.28F, 12.67F, 8.77F, 15.34F},
  { 0, 0x00000000, "Asia/Shanghai", 8.00F, 22.68F, 40.19F, 112.63F, 122.48F},
  { 0, 0x00000000, "Asia/Harbin", 8.00F, 38.93F, 52.43F, 111.88F, 132.31F},
  { 0, 0x00000000, "Asia/Chongqing", 8.00F, 18.14F, 40.91F, 91.00F, 114.82F},
  { 0, 0x00000000, "Asia/Urumqi", 8.00F, 39.67F, 47.97F, 82.84F, 98.67F},
  { 0, 0x00000000, "Asia/Kashgar", 8.00F, 37.00F, 41.22F, 75.88F, 81.36F},
  { 0, 0x00000000, "America/Bogota", -5.00F, -4.32F, 13.47F, -81.80F, -67.37F},
  { 0, 0x00000000, "America/Costa_Rica", -6.00F, 8.43F, 11.17F, -85.75F, -82.52F},
  {60, 0x40559055, "America/Havana", -5.00F, 19.92F, 23.25F, -84.38F, -74.40F},
  { 0, 0x00000000, "Atlantic/Cape_Verde", -1.00F, 14.80F, 17.30F, -25.20F, -22.80F},
  { 0, 0x00000000, "Indian/Christmas", 7.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3050a050, "Asia/Nicosia", 2.00F, 34.57F, 35.70F, 32.28F, 34.48F},
  {60, 0x3050a050, "Europe/Prague", 1.00F, 48.52F, 51.10F, 12.08F, 18.93F},
  {60, 0x3050a050, "Europe/Berlin", 1.00F, 47.30F, 55.12F, 5.88F, 15.10F},
  { 0, 0x00000000, "Africa/Djibouti", 3.00F, 11.01F, 12.52F, 41.74F, 43.39F},
  {60, 0x3050a050, "Europe/Copenhagen", 1.00F, 54.55F, 57.83F, 8.03F, 15.25F},
  { 0, 0x00000000, "America/Dominica", -4.00F, 15.13F, 15.68F, -61.57F, -61.15F},
  { 0, 0x00000000, "America/Santo_Domingo", -4.00F, 17.68F, 20.00F, -71.95F, -68.50F},
  { 0, 0x00000000, "Africa/Algiers", 1.00F, 22.68F, 37.03F, -2.32F, 8.57F},
  { 0, 0x00000000, "America/Guayaquil", -5.00F, -4.48F, 1.39F, -81.07F, -76.78F},
  { 0, 0x00000000, "Pacific/Galapagos", -6.00F, -1.02F, -0.65F, -90.42F, -89.47F},
  {60, 0x3050a050, "Europe/Tallinn", 2.00F, 57.67F, 59.68F, 22.40F, 28.29F},
  {60, 0x3056a050, "Africa/Cairo", 2.00F, 23.99F, 31.61F, 27.13F, 34.61F},
  { 0, 0x00000000, "Africa/El_Aaiun", 0.00F, 27.04F, 27.24F, -13.26F, -13.06F},
  { 0, 0x00000000, "Africa/Asmara", 3.00F, 13.83F, 15.65F, 36.56F, 41.79F},
  {60, 0x3050a050, "Europe/Madrid", 1.00F, 36.88F, 43.85F, -9.29F, 4.37F},
  {60, 0x3050a050, "Africa/Ceuta", 1.00F, 35.19F, 38.23F, -7.50F, -2.10F},
  {60, 0x3050a050, "Atlantic/Canary", 0.00F, 27.78F, 29.23F, -18.07F, -13.38F},
  { 0, 0x00000000, "Africa/Addis_Ababa", 3.00F, 3.95F, 14.23F, 34.43F, 42.90F},
  {60, 0x3050a050, "Europe/Helsinki", 2.00F, 59.73F, 69.98F, 19.52F, 31.02F},
  { 0, 0x00000000, "Pacific/Fiji", 12.00F, -16.52F, -16.32F, 179.28F, 179.48F},
  {60, 0x3050a050, "Atlantic/Stanley", -3.00F, -51.80F, -51.60F, -57.95F, -57.75F},
  { 0, 0x00000000, "Pacific/Truk", 10.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Pacific/Ponape", 11.00F, 6.82F, 9.61F, 138.03F, 158.37F},
  { 0, 0x00000000, "Pacific/Kosrae", 11.00F, 5.21F, 5.46F, 162.88F, 163.10F},
  {60, 0x3050a050, "Atlantic/Faroe", 0.00F, 61.37F, 62.33F, -7.40F, -6.50F},
  {60, 0x3050a050, "Europe/Paris", 1.00F, 41.29F, 51.18F, -4.87F, 9.62F},
  { 0, 0x00000000, "Africa/Libreville", 1.00F, -3.52F, 2.18F, 8.68F, 14.33F},
  {60, 0x3050a050, "Europe/London", 0.00F, 49.93F, 60.25F, -7.73F, 1.85F},
  { 0, 0x00000000, "America/Grenada", -4.00F, 11.93F, 12.32F, -61.83F, -61.52F},
  { 0, 0x00000000, "Asia/Tbilisi", 4.00F, 41.17F, 43.43F, 40.12F, 46.38F},
  { 0, 0x00000000, "America/Cayenne", -3.00F, 3.07F, 5.77F, -54.48F, -51.70F},
  {60, 0x3050a050, "Europe/Guernsey", 0.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Africa/Accra", 0.00F, 4.77F, 11.16F, -2.68F, 1.08F},
  {60, 0x3050a050, "Europe/Gibraltar", 1.00F, 36.03F, 36.23F, -5.45F, -5.25F},
  {60, 0x3050a050, "America/Godthab", -3.00F, 60.02F, 72.88F, -56.27F, -37.53F},
  { 0, 0x00000000, "America/Danmarkshavn", 0.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3050a050, "America/Scoresbysund", -1.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020b010, "America/Thule", -4.00F, 77.20F, 77.40F, -68.94F, -68.74F},
  { 0, 0x00000000, "Africa/Banjul", 0.00F, 13.10F, 13.88F, -16.83F, -13.75F},
  { 0, 0x00000000, "Africa/Conakry", 0.00F, 7.46F, 12.63F, -14.47F, -8.43F},
  { 0, 0x00000000, "America/Guadeloupe", -4.00F, 15.75F, 17.98F, -62.95F, -60.97F},
  { 0, 0x00000000, "Africa/Malabo", 1.00F, -1.50F, 3.85F, 5.53F, 11.43F},
  {60, 0x3050a050, "Europe/Athens", 2.00F, 34.90F, 41.75F, 19.73F, 28.32F},
  { 0, 0x00000000, "Atlantic/South_Georgia", -2.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "America/Guatemala", -6.00F, 13.83F, 17.17F, -92.29F, -88.50F},
  { 0, 0x00000000, "Pacific/Guam", 10.00F, 13.16F, 13.63F, 144.55F, 144.99F},
  { 0, 0x00000000, "Africa/Bissau", 0.00F, 11.18F, 12.58F, -16.27F, -14.12F},
  { 0, 0x00000000, "America/Guyana", -4.00F, 5.78F, 6.91F, -58.72F, -57.03F},
  { 0, 0x00000000, "Asia/Hong_Kong", 8.00F, 22.18F, 22.42F, 114.05F, 114.28F},
  { 0, 0x00000000, "America/Tegucigalpa", -6.00F, 13.02F, 16.55F, -89.30F, -83.13F},
  {60, 0x3050a050, "Europe/Zagreb", 1.00F, 42.48F, 46.60F, 13.42F, 19.48F},
  { 0, 0x00000000, "America/Port-au-Prince", -5.00F, 17.95F, 20.03F, -74.55F, -71.63F},
  {60, 0x3050a050, "Europe/Budapest", 1.00F, 45.69F, 48.57F, 16.23F, 22.78F},
  { 0, 0x00000000, "Asia/Jakarta", 7.00F, -8.27F, 4.12F, 98.18F, 112.77F},
  { 0, 0x00000000, "Asia/Pontianak", 7.00F, -3.20F, 5.99F, 95.22F, 114.45F},
  { 0, 0x00000000, "Asia/Makassar", 8.00F, -10.27F, 7.70F, 99.68F, 125.26F},
  { 0, 0x00000000, "Asia/Jayapura", 9.00F, -5.77F, 1.83F, 127.30F, 140.80F},
  {60, 0x3050a050, "Europe/Dublin", 0.00F, 51.45F, 55.35F, -10.37F, -5.95F},
  {60, 0x4410a410, "Asia/Jerusalem", 2.00F, 29.46F, 33.31F, 34.48F, 35.67F},
  {60, 0x3050a050, "Europe/Isle_of_Man", 0.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Asia/Calcutta", 5.50F, 7.98F, 34.67F, 68.73F, 96.27F},
  { 0, 0x00000000, "Indian/Chagos", 6.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x90504010, "Asia/Baghdad", 3.00F, 29.87F, 37.24F, 40.18F, 48.57F},
  { 0, 0x90504010, "Asia/Tehran", 3.50F, 25.20F, 39.75F, 44.67F, 61.60F},
  { 0, 0x00000000, "Atlantic/Reykjavik", 0.00F, 63.73F, 66.25F, -23.25F, -13.60F},
  {60, 0x3050a050, "Europe/Rome", 1.00F, 35.40F, 47.10F, 6.60F, 18.59F},
  {60, 0x3050a050, "Europe/Jersey", 0.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "America/Jamaica", -5.00F, 17.67F, 18.60F, -78.27F, -76.13F},
  {60, 0x3050a050, "Asia/Amman", 2.00F, 29.43F, 32.80F, 34.91F, 36.73F},
  { 0, 0x00000000, "Asia/Tokyo", 9.00F, 24.23F, 45.51F, 124.05F, 145.67F},
  { 0, 0x00000000, "Africa/Nairobi", 3.00F, -4.75F, 4.03F, 33.87F, 41.95F},
  { 0, 0x00000000, "Asia/Bishkek", 6.00F, 39.73F, 42.99F, 69.42F, 78.50F},
  { 0, 0x00000000, "Asia/Phnom_Penh", 7.00F, 10.38F, 13.92F, 102.51F, 107.30F},
  { 0, 0x00000000, "Pacific/Tarawa", 12.00F, -1.45F, 3.18F, 172.72F, 176.53F},
  { 0, 0x00000000, "Pacific/Enderbury", 13.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Pacific/Kiritimati", 14.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Indian/Comoro", 3.00F, -12.46F, -11.28F, 43.14F, 44.63F},
  { 0, 0x00000000, "America/St_Kitts", -4.00F, 17.03F, 17.40F, -62.82F, -62.52F},
  { 0, 0x00000000, "Asia/Pyongyang", 9.00F, 37.81F, 43.06F, 124.30F, 130.56F},
  { 0, 0x00000000, "Asia/Seoul", 9.00F, 33.36F, 37.97F, 126.22F, 129.45F},
  { 0, 0x00000000, "Asia/Kuwait", 3.00F, 28.54F, 29.54F, 47.83F, 48.37F},
  { 0, 0x00000000, "America/Cayman", -5.00F, 19.18F, 19.47F, -81.52F, -81.02F},
  { 0, 0x00000000, "Asia/Almaty", 6.00F, 42.65F, 53.64F, 71.27F, 84.97F},
  { 0, 0x00000000, "Asia/Qyzylorda", 6.00F, 40.57F, 55.01F, 63.40F, 73.21F},
  { 0, 0x00000000, "Asia/Aqtobe", 5.00F, 43.82F, 54.53F, 53.22F, 67.43F},
  { 0, 0x00000000, "Asia/Aqtau", 5.00F, 43.10F, 47.77F, 49.17F, 55.30F},
  { 0, 0x00000000, "Asia/Oral", 5.00F, 48.45F, 51.53F, 46.73F, 54.18F},
  { 0, 0x00000000, "Asia/Vientiane", 7.00F, 14.70F, 21.52F, 101.30F, 106.93F},
  {60, 0x3050a050, "Asia/Beirut", 2.00F, 33.17F, 34.54F, 35.09F, 36.32F},
  { 0, 0x00000000, "America/St_Lucia", -4.00F, 13.62F, 14.17F, -61.15F, -60.78F},
  {60, 0x3050a050, "Europe/Vaduz", 1.00F, 46.97F, 47.33F, 9.40F, 9.63F},
  { 0, 0x00000000, "Asia/Colombo", 5.50F, 5.87F, 9.92F, 79.70F, 81.92F},
  { 0, 0x00000000, "Africa/Monrovia", 0.00F, 4.28F, 7.68F, -11.47F, -7.62F},
  { 0, 0x00000000, "Africa/Maseru", 2.00F, -30.50F, -28.68F, 27.15F, 29.18F},
  {60, 0x3050a050, "Europe/Vilnius", 2.00F, 53.92F, 56.46F, 20.96F, 26.52F},
  {60, 0x3050a050, "Europe/Luxembourg", 1.00F, 49.38F, 50.22F, 5.74F, 6.60F},
  {60, 0x3050a050, "Europe/Riga", 2.00F, 55.78F, 58.00F, 20.92F, 28.22F},
  { 0, 0x00000000, "Africa/Tripoli", 2.00F, 24.12F, 33.05F, 10.07F, 25.20F},
  { 0, 0x00000000, "Africa/Casablanca", 0.00F, 28.33F, 35.88F, -11.20F, -1.12F},
  {60, 0x3050a050, "Europe/Monaco", 1.00F, 43.63F, 43.83F, 7.32F, 7.52F},
  {60, 0x3050a050, "Europe/Chisinau", 2.00F, 45.58F, 48.46F, 27.21F, 30.06F},
  {60, 0x3050a050, "Europe/Podgorica", 1.00F, 41.83F, 43.25F, 18.56F, 19.43F},
  { 0, 0x00000000, "America/Marigot", 0.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Indian/Antananarivo", 3.00F, -25.40F, -12.17F, 43.57F, 50.38F},
  { 0, 0x00000000, "Pacific/Majuro", 12.00F, 7.00F, 7.20F, 171.28F, 171.48F},
  { 0, 0x00000000, "Pacific/Kwajalein", 12.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3050a050, "Europe/Skopje", 1.00F, 40.84F, 42.33F, 20.43F, 22.99F},
  { 0, 0x00000000, "Africa/Bamako", 0.00F, -0.14F, 22.78F, -11.53F, 16.37F},
  { 0, 0x00000000, "Asia/Rangoon", 6.50F, 12.33F, 25.48F, 92.80F, 98.70F},
  { 0, 0x00000000, "Asia/Ulaanbaatar", 8.00F, 43.47F, 50.33F, 91.97F, 113.38F},
  { 0, 0x00000000, "Asia/Hovd", 7.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Asia/Choibalsan", 9.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Asia/Macau", 8.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Pacific/Saipan", 10.00F, 14.04F, 15.35F, 145.04F, 145.87F},
  { 0, 0x00000000, "America/Martinique", -4.00F, 14.37F, 14.97F, -61.27F, -60.73F},
  { 0, 0x00000000, "Africa/Nouakchott", 0.00F, 18.02F, 18.22F, -16.14F, -15.94F},
  { 0, 0x00000000, "America/Montserrat", -4.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3050a050, "Europe/Malta", 1.00F, 35.73F, 36.15F, 14.13F, 14.64F},
  { 0, 0x00000000, "Indian/Mauritius", 4.00F, -20.62F, -19.88F, 57.26F, 57.88F},
  { 0, 0x00000000, "Indian/Maldives", 5.00F, -0.70F, 6.98F, 72.80F, 73.67F},
  { 0, 0x00000000, "Africa/Blantyre", 2.00F, -17.02F, -9.62F, 32.80F, 35.75F},
  {60, 0x35d09550, "America/Mexico_City", -6.00F, 15.63F, 22.83F, -105.35F, -93.65F},
  {60, 0x35d09550, "America/Cancun", -6.00F, 19.48F, 21.30F, -88.25F, -86.62F},
  {60, 0x35d09550, "America/Merida", -6.00F, 14.45F, 21.38F, -93.82F, -88.10F},
  {60, 0x35d09550, "America/Monterrey", -6.00F, 21.88F, 31.87F, -108.37F, -97.40F},
  {60, 0x35d09550, "America/Mazatlan", -7.00F, 16.42F, 26.03F, -110.40F, -98.65F},
  {60, 0x35d09550, "America/Chihuahua", -7.00F, 25.98F, 26.81F, -108.87F, -108.22F},
  { 0, 0x00000000, "America/Hermosillo", -7.00F, 24.94F, 32.56F, -115.10F, -108.83F},
  {60, 0x35d09550, "America/Tijuana", -8.00F, 28.28F, 32.80F, -117.13F, -113.25F},
  { 0, 0x00000000, "Asia/Kuala_Lumpur", 8.00F, 1.35F, 6.53F, 99.75F, 104.00F},
  { 0, 0x00000000, "Asia/Kuching", 8.00F, 1.15F, 6.98F, 110.23F, 118.72F},
  { 0, 0x00000000, "Africa/Maputo", 2.00F, -26.07F, -11.22F, 32.36F, 40.84F},
  {60, 0x40109010, "Africa/Windhoek", 2.00F, -28.65F, -17.30F, 13.75F, 24.37F},
  { 0, 0x00000000, "Pacific/Noumea", 11.00F, -22.77F, -20.13F, 163.92F, 167.98F},
  { 0, 0x00000000, "Africa/Niamey", 1.00F, 11.79F, 18.79F, 0.65F, 13.21F},
  { 0, 0x00000000, "Pacific/Norfolk", 11.50F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Africa/Lagos", 1.00F, 4.22F, 13.83F, 2.63F, 14.32F},
  { 0, 0x00000000, "America/Managua", -6.00F, 11.02F, 14.83F, -87.28F, -82.93F},
  {60, 0x3050a050, "Europe/Amsterdam", 1.00F, 50.67F, 53.55F, 3.47F, 7.21F},
  {60, 0x3050a050, "Europe/Oslo", 1.00F, 57.93F, 71.10F, 4.90F, 31.20F},
  { 0, 0x00000000, "Asia/Katmandu", 5.75F, 26.38F, 29.95F, 80.23F, 88.18F},
  { 0, 0x00000000, "Pacific/Nauru", 12.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Pacific/Niue", -11.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020a030, "Pacific/Auckland", 13.00F, -46.70F, -34.88F, 167.62F, 178.10F},
  {60, 0x3020a030, "Pacific/Chatham", 13.75F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Asia/Muscat", 4.00F, 16.92F, 26.29F, 53.98F, 59.63F},
  { 0, 0x00000000, "America/Panama", -5.00F, 7.30F, 9.65F, -82.97F, -77.58F},
  { 0, 0x00000000, "America/Lima", -5.00F, -18.11F, -3.38F, -81.37F, -68.94F},
  { 0, 0x00000000, "Pacific/Tahiti", -10.00F, -22.53F, -16.38F, -151.85F, -149.05F},
  { 0, 0x00000000, "Pacific/Marquesas", -9.50F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Pacific/Gambier", -9.00F, -23.22F, -9.70F, -139.13F, -134.87F},
  { 0, 0x00000000, "Pacific/Port_Moresby", 10.00F, -10.72F, -1.92F, 141.20F, 155.73F},
  { 0, 0x00000000, "Asia/Manila", 8.00F, 4.55F, 20.55F, 116.96F, 126.68F},
  { 0, 0x00000000, "Asia/Karachi", 5.00F, 24.04F, 36.02F, 61.64F, 75.27F},
  {60, 0x3050a050, "Europe/Warsaw", 1.00F, 49.20F, 54.90F, 14.15F, 24.02F},
  {60, 0x3020b010, "America/Miquelon", -3.00F, 46.67F, 47.20F, -56.48F, -56.08F},
  { 0, 0x00000000, "Pacific/Pitcairn", -8.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "America/Puerto_Rico", -4.00F, 17.85F, 18.60F, -67.35F, -65.20F},
  {60, 0x3055a010, "Asia/Gaza", 2.00F, 31.18F, 32.65F, 34.15F, 35.55F},
  {60, 0x3050a050, "Europe/Lisbon", 0.00F, 36.92F, 41.97F, -9.55F, -6.62F},
  {60, 0x3050a050, "Atlantic/Madeira", 0.00F, 32.53F, 33.18F, -17.20F, -16.23F},
  {60, 0x3050a050, "Atlantic/Azores", -1.00F, 37.62F, 39.15F, -28.80F, -25.33F},
  { 0, 0x00000000, "Pacific/Palau", 9.00F, 7.25F, 7.45F, 134.35F, 134.55F},
  {60, 0x4010a050, "America/Asuncion", -3.00F, -27.50F, -19.82F, -60.88F, -54.25F},
  { 0, 0x00000000, "Asia/Qatar", 3.00F, 25.05F, 26.23F, 50.69F, 51.71F},
  { 0, 0x00000000, "Indian/Reunion", 4.00F, -21.47F, -20.77F, 55.17F, 55.88F},
  {60, 0x3050a050, "Europe/Bucharest", 2.00F, 43.57F, 48.33F, 20.22F, 29.77F},
  {60, 0x3050a050, "Europe/Belgrade", 1.00F, 42.16F, 46.15F, 18.83F, 22.35F},
  {60, 0x3050a050, "Europe/Kaliningrad", 2.00F, 54.26F, 61.22F, 19.80F, 28.95F},
  {60, 0x3050a050, "Europe/Moscow", 3.00F, 50.38F, 69.65F, 27.50F, 64.52F},
  {60, 0x3050a050, "Europe/Volgograd", 3.00F, 41.18F, 55.82F, 36.61F, 54.18F},
  {60, 0x3050a050, "Europe/Samara", 4.00F, 45.67F, 60.72F, 41.66F, 54.28F},
  {60, 0x3050a050, "Asia/Yekaterinburg", 5.00F, 50.65F, 67.57F, 51.93F, 78.80F},
  {60, 0x3050a050, "Asia/Omsk", 6.00F, 53.68F, 57.79F, 71.07F, 75.35F},
  {60, 0x3050a050, "Asia/Novosibirsk", 6.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3050a050, "Asia/Krasnoyarsk", 7.00F, 49.90F, 73.61F, 75.60F, 102.60F},
  {60, 0x3050a050, "Asia/Irkutsk", 8.00F, 49.50F, 61.38F, 97.53F, 128.78F},
  {60, 0x3050a050, "Asia/Yakutsk", 9.00F, 49.31F, 72.02F, 108.65F, 133.07F},
  {60, 0x3050a050, "Asia/Vladivostok", 10.00F, 42.53F, 50.18F, 130.68F, 136.71F},
  {60, 0x3050a050, "Asia/Sakhalin", 10.00F, 46.44F, 70.12F, 132.46F, 143.40F},
  {60, 0x3050a050, "Asia/Magadan", 11.00F, 43.97F, 70.73F, 141.75F, 161.40F},
  {60, 0x3050a050, "Asia/Kamchatka", 12.00F, 51.40F, 59.34F, 156.42F, 163.17F},
  {60, 0x3050a050, "Asia/Anadyr", 12.00F, 60.37F, 69.80F, -179.27F, 179.41F},
  { 0, 0x00000000, "Africa/Kigali", 2.00F, -2.70F, -1.40F, 28.80F, 30.64F},
  { 0, 0x00000000, "Asia/Riyadh", 3.00F, 16.48F, 31.78F, 36.37F, 50.23F},
  { 0, 0x00000000, "Pacific/Guadalcanal", 11.00F, -10.55F, -8.00F, 156.75F, 162.02F},
  { 0, 0x00000000, "Indian/Mahe", 4.00F, -4.72F, -4.52F, 55.35F, 55.55F},
  { 0, 0x00000000, "Africa/Khartoum", 3.00F, 3.99F, 21.17F, 22.35F, 37.83F},
  {60, 0x3050a050, "Europe/Stockholm", 1.00F, 55.27F, 67.95F, 11.82F, 22.25F},
  { 0, 0x00000000, "Asia/Singapore", 8.00F, 1.19F, 1.39F, 103.76F, 103.96F},
  { 0, 0x00000000, "Atlantic/St_Helena", 0.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3050a050, "Europe/Ljubljana", 1.00F, 45.40F, 46.78F, 13.47F, 16.55F},
  {60, 0x3050a050, "Arctic/Longyearbyen", 1.00F, 78.12F, 78.32F, 15.53F, 15.73F},
  {60, 0x3050a050, "Europe/Bratislava", 1.00F, 47.66F, 49.53F, 16.92F, 22.28F},
  { 0, 0x00000000, "Africa/Freetown", 0.00F, 7.15F, 10.02F, -13.39F, -10.27F},
  {60, 0x3050a050, "Europe/San_Marino", 1.00F, 43.83F, 44.05F, 12.32F, 12.60F},
  { 0, 0x00000000, "Africa/Dakar", 0.00F, 12.38F, 16.62F, -17.56F, -12.08F},
  { 0, 0x00000000, "Africa/Mogadishu", 3.00F, -1.32F, 11.95F, 41.75F, 51.18F},
  { 0, 0x00000000, "America/Paramaribo", -3.00F, 4.92F, 6.05F, -57.08F, -53.95F},
  { 0, 0x00000000, "Africa/Sao_Tome", 0.00F, 0.23F, 0.43F, 6.63F, 6.83F},
  { 0, 0x00000000, "America/El_Salvador", -6.00F, 13.10F, 14.43F, -90.12F, -87.74F},
  {60, 0x0041a198, "Asia/Damascus", 2.00F, 32.60F, 37.17F, 35.68F, 41.02F},
  { 0, 0x00000000, "Africa/Mbabane", 2.00F, -27.42F, -25.87F, 30.92F, 32.05F},
  {60, 0x3020b010, "America/Grand_Turk", -5.00F, 21.37F, 21.57F, -71.23F, -71.03F},
  { 0, 0x00000000, "Africa/Ndjamena", 1.00F, 8.17F, 21.94F, 14.05F, 22.30F},
  { 0, 0x00000000, "Indian/Kerguelen", 5.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Africa/Lome", 0.00F, 6.03F, 10.96F, 0.10F, 1.70F},
  { 0, 0x00000000, "Asia/Bangkok", 7.00F, 5.65F, 20.53F, 97.83F, 105.33F},
  { 0, 0x00000000, "Asia/Dushanbe", 5.00F, 37.14F, 40.77F, 67.51F, 74.06F},
  { 0, 0x00000000, "Pacific/Fakaofo", -10.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Asia/Dili", 9.00F, -8.66F, -8.46F, 125.47F, 125.67F},
  { 0, 0x00000000, "Asia/Ashgabat", 5.00F, 37.20F, 42.23F, 52.87F, 66.16F},
  {60, 0x3050a050, "Africa/Tunis", 1.00F, 32.22F, 37.37F, 7.78F, 11.32F},
  { 0, 0x00000000, "Pacific/Tongatapu", 13.00F, -21.43F, -18.55F, -175.32F, -173.88F},
  {60, 0x3050a050, "Europe/Istanbul", 2.00F, 35.80F, 42.13F, 25.82F, 44.67F},
  { 0, 0x00000000, "America/Port_of_Spain", -4.00F, 10.03F, 11.28F, -61.78F, -60.63F},
  { 0, 0x00000000, "Pacific/Funafuti", 12.00F, -8.62F, -8.42F, 179.12F, 179.32F},
  { 0, 0x00000000, "Asia/Taipei", 8.00F, 22.52F, 25.23F, 120.20F, 121.84F},
  { 0, 0x00000000, "Africa/Dar_es_Salaam", 3.00F, -11.47F, -1.04F, 29.53F, 40.43F},
  {60, 0x3050a050, "Europe/Kiev", 2.00F, 46.91F, 52.29F, 25.72F, 35.06F},
  {60, 0x3050a050, "Europe/Uzhgorod", 2.00F, 47.85F, 51.77F, 22.10F, 26.60F},
  {60, 0x3050a050, "Europe/Zaporozhye", 2.00F, 46.27F, 50.87F, 30.82F, 40.20F},
  {60, 0x3050a050, "Europe/Simferopol", 2.00F, 44.32F, 47.07F, 28.18F, 36.58F},
  { 0, 0x00000000, "Africa/Kampala", 3.00F, -0.98F, 3.38F, 29.55F, 35.05F},
  { 0, 0x00000000, "Pacific/Johnston", -10.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Pacific/Midway", -11.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Pacific/Wake", 12.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020b010, "America/New_York", -5.00F, 34.58F, 47.46F, -79.22F, -66.88F},
  {60, 0x3020b010, "America/Detroit", -5.00F, 39.00F, 47.34F, -89.41F, -77.93F},
  {60, 0x3020b010, "America/Kentucky/Louisville", -5.00F, 37.47F, 38.90F, -86.09F, -84.74F},
  {60, 0x3020b010, "America/Kentucky/Monticello", -5.00F, 24.46F, 38.07F, -85.61F, -77.22F},
  {60, 0x3020b010, "America/Indiana/Indianapolis", -5.00F, 39.06F, 42.32F, -87.56F, -83.79F},
  {60, 0x3020b010, "America/Indiana/Vincennes", -5.00F, 38.58F, 38.87F, -87.63F, -87.21F},
  {60, 0x3020b010, "America/Indiana/Knox", -6.00F, 25.77F, 41.84F, -98.85F, -84.75F},
  {60, 0x3020b010, "America/Indiana/Winamac", -5.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020b010, "America/Indiana/Marengo", -5.00F, 37.81F, 39.23F, -87.51F, -85.92F},
  {60, 0x3020b010, "America/Indiana/Vevay", -5.00F, 37.76F, 40.46F, -85.99F, -79.28F},
  {60, 0x3020b010, "America/Chicago", -6.00F, 26.26F, 43.57F, -102.00F, -87.08F},
  {60, 0x3020b010, "America/Indiana/Tell_City", -6.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020b010, "America/Indiana/Petersburg", -5.00F, 26.00F, 38.94F, -97.39F, -85.50F},
  {60, 0x3020b010, "America/Menominee", -6.00F, 43.30F, 48.70F, -95.09F, -87.28F},
  {60, 0x3020b010, "America/North_Dakota/Center", -6.00F, 45.53F, 49.01F, -103.72F, -94.19F},
  {60, 0x3020b010, "America/North_Dakota/New_Salem", -6.00F, 29.46F, 46.93F, -104.93F, -94.61F},
  {60, 0x3020b010, "America/Denver", -7.00F, 36.35F, 48.89F, -110.44F, -100.75F},
  {60, 0x3020b010, "America/Boise", -7.00F, 40.12F, 48.98F, -117.34F, -106.54F},
  {60, 0x3020b010, "America/Shiprock", -7.00F, 32.01F, 40.81F, -113.82F, -102.95F},
  { 0, 0x00000000, "America/Phoenix", -7.00F, 31.20F, 37.27F, -114.88F, -105.75F},
  {60, 0x3020b010, "America/Los_Angeles", -8.00F, 32.48F, 49.10F, -124.60F, -113.97F},
  {60, 0x3020b010, "America/Anchorage", -9.00F, 57.69F, 64.96F, -158.56F, -142.89F},
  {60, 0x3020b010, "America/Juneau", -9.00F, 55.03F, 59.34F, -135.55F, -131.47F},
  {60, 0x3020b010, "America/Yakutat", -9.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  {60, 0x3020b010, "America/Nome", -9.00F, 60.69F, 71.39F, -166.20F, -156.69F},
  {60, 0x3020b010, "America/Adak", -10.00F, 53.77F, 53.97F, -166.64F, -166.44F},
  { 0, 0x00000000, "Pacific/Honolulu", -10.00F, 18.97F, 22.32F, -159.81F, -154.81F},
  {60, 0x3020b010, "America/Montevideo", -2.00F, -35.07F, -30.13F, -58.52F, -53.32F},
  { 0, 0x00000000, "Asia/Samarkand", 5.00F, 37.12F, 43.17F, 58.79F, 68.00F},
  { 0, 0x00000000, "Asia/Tashkent", 5.00F, 39.86F, 41.65F, 67.74F, 72.86F},
  {60, 0x3050a050, "Europe/Vatican", 1.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "America/St_Vincent", -4.00F, 13.06F, 13.37F, -61.34F, -61.02F},
  { 0, 0x00000000, "America/Caracas", -4.00F, 5.56F, 11.80F, -72.64F, -61.95F},
  { 0, 0x00000000, "America/Tortola", -4.00F, 18.32F, 18.52F, -64.72F, -64.52F},
  { 0, 0x00000000, "America/St_Thomas", -4.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Asia/Saigon", 7.00F, 9.08F, 22.93F, 102.92F, 109.40F},
  { 0, 0x00000000, "Pacific/Efate", 11.00F, -19.65F, -13.78F, 166.95F, 169.37F},
  { 0, 0x00000000, "Pacific/Wallis", 12.00F, 0.90F, 0.10F, -0.10F, 0.10F},
  { 0, 0x00000000, "Pacific/Apia", -11.00F, -14.12F, -13.35F, -172.50F, -171.45F},
  { 0, 0x00000000, "Asia/Aden", 3.00F, 12.68F, 15.79F, 42.85F, 49.23F},
  { 0, 0x00000000, "Indian/Mayotte", 3.00F, -13.05F, -12.60F, 44.96F, 45.37F},
  { 0, 0x00000000, "Africa/Johannesburg", 2.00F, -34.63F, -22.25F, 17.78F, 32.20F},
  { 0, 0x00000000, "Africa/Lusaka", 2.00F, -17.95F, -8.37F, 22.58F, 33.28F},
  { 0, 0x00000000, "Africa/Harare", 2.00F, -22.32F, -15.93F, 25.73F, 32.97F},
  { 0, 0x00000000, "UTC-12", -12.00F, -90.0F, +90.0F, 157.50F, -172.50F},
  { 0, 0x00000000, "UTC-11", -11.00F, -90.0F, +90.0F, 172.50F, -157.50F},
  { 0, 0x00000000, "UTC-10", -10.00F, -90.0F, +90.0F, -172.50F, -142.50F},
  { 0, 0x00000000, "UTC-9:30", -9.50F, -90.0F, +90.0F, -165.00F, -135.00F},
  { 0, 0x00000000, "UTC-9", -9.00F, -90.0F, +90.0F, -157.50F, -127.50F},
  { 0, 0x00000000, "UTC-8", -8.00F, -90.0F, +90.0F, -142.50F, -112.50F},
  { 0, 0x00000000, "UTC-7", -7.00F, -90.0F, +90.0F, -127.50F, -97.50F},
  { 0, 0x00000000, "UTC-6", -6.00F, -90.0F, +90.0F, -112.50F, -82.50F},
  { 0, 0x00000000, "UTC-5", -5.00F, -90.0F, +90.0F, -97.50F, -67.50F},
  { 0, 0x00000000, "UTC-4:30", -4.50F, -90.0F, +90.0F, -90.00F, -60.00F},
  { 0, 0x00000000, "UTC-4", -4.00F, -90.0F, +90.0F, -82.50F, -52.50F},
  { 0, 0x00000000, "UTC-3:30", -3.50F, -90.0F, +90.0F, -75.00F, -45.00F},
  { 0, 0x00000000, "UTC-3", -3.00F, -90.0F, +90.0F, -67.50F, -37.50F},
  { 0, 0x00000000, "UTC-2", -2.00F, -90.0F, +90.0F, -52.50F, -22.50F},
  { 0, 0x00000000, "UTC-1", -1.00F, -90.0F, +90.0F, -37.50F, -7.50F},
  { 0, 0x00000000, "UTC", +0.00F, -90.0F, +90.0F, -22.50F, 7.50F},
  { 0, 0x00000000, "UTC+1", +1.00F, -90.0F, +90.0F, -7.50F, 22.50F},
  { 0, 0x00000000, "UTC+2", +2.00F, -90.0F, +90.0F, 7.50F, 37.50F},
  { 0, 0x00000000, "UTC+3", +3.00F, -90.0F, +90.0F, 22.50F, 52.50F},
  { 0, 0x00000000, "UTC+3:30", +3.50F, -90.0F, +90.0F, 30.00F, 60.00F},
  { 0, 0x00000000, "UTC+4", +4.00F, -90.0F, +90.0F, 37.50F, 67.50F},
  { 0, 0x00000000, "UTC+4:30", +4.50F, -90.0F, +90.0F, 45.00F, 75.00F},
  { 0, 0x00000000, "UTC+5", +5.00F, -90.0F, +90.0F, 52.50F, 82.50F},
  { 0, 0x00000000, "UTC+5:30", +5.50F, -90.0F, +90.0F, 60.00F, 90.00F},
  { 0, 0x00000000, "UTC+5:45", +5.75F, -90.0F, +90.0F, 63.75F, 93.75F},
  { 0, 0x00000000, "UTC+6", +6.00F, -90.0F, +90.0F, 67.50F, 97.50F},
  { 0, 0x00000000, "UTC+6:30", +6.50F, -90.0F, +90.0F, 75.00F, 105.00F},
  { 0, 0x00000000, "UTC+7", +7.00F, -90.0F, +90.0F, 82.50F, 112.50F},
  { 0, 0x00000000, "UTC+8", +8.00F, -90.0F, +90.0F, 97.50F, 127.50F},
  { 0, 0x00000000, "UTC+8:45", +8.75F, -90.0F, +90.0F, 108.75F, 138.75F},
  { 0, 0x00000000, "UTC+9", +9.00F, -90.0F, +90.0F, 112.50F, 142.50F},
  { 0, 0x00000000, "UTC+9:30", +9.50F, -90.0F, +90.0F, 120.00F, 150.00F},
  { 0, 0x00000000, "UTC+10", +10.00F, -90.0F, +90.0F, 127.50F, 157.50F},
  { 0, 0x00000000, "UTC+10:30", +10.50F, -90.0F, +90.0F, 135.00F, 165.00F},
  { 0, 0x00000000, "UTC+11", +11.00F, -90.0F, +90.0F, 142.50F, 172.50F},
  { 0, 0x00000000, "UTC+11:30", +11.50F, -90.0F, +90.0F, 150.00F, 180.00F},
  { 0, 0x00000000, "UTC+12", +12.00F, -90.0F, +90.0F, 157.50F, -172.50F},
  { 0, 0x00000000, "UTC+12:45", +12.75F, -90.0F, +90.0F, 168.75F, -161.25F},
  { 0, 0x00000000, "UTC+13", +13.00F, -90.0F, +90.0F, 172.50F, -157.50F},
  { 0, 0x00000000, "UTC+14", +14.00F, -90.0F, +90.0F, -172.50F, -142.50F}
};

const char * TTimeZone::GetTimeZoneName(int nIndex)
{
	return gzone[nIndex].name;
}

double TTimeZone::GetTimeZoneOffset(int nIndex)
{
	return gzone[nIndex].tzone;
}

int TTimeZone::GetTimeZoneCount()
{
	return sizeof(gzone)/sizeof(TTimeZone);
}

Boolean TTimeZone::GetXMLString(TString &str, int nIndex)
{
	static int DSTtable[8];
	int bias = 60;

	if (nIndex < 0 || nIndex >= GetTimeZoneCount())
		return false;

	ExpandVal(gzone[nIndex].val, DSTtable);


	
	str.Format("\t<dayss name=\"%s\" types=\"%d\" months=\"%d\" weeks=\"%d\" days=\"%d\"\n\t\ttypee=\"%d\" monthe=\"%d\" weeke=\"%d\" daye=\"%d\" shift=\"%d\"/>\n"
				, gzone[nIndex].name, DSTtable[1],  DSTtable[0], DSTtable[2], DSTtable[3],
				 DSTtable[5], DSTtable[4], DSTtable[6], DSTtable[7], gzone[nIndex].bias);

	return true;
}

void TTimeZone::ExpandVal(UInt32 val, int a[])
{
	a[7] = val & 0xf;
	val >>= 4;
	a[6] = val & 0x3f;
	val >>= 6;
	a[5] = val & 0x3;
	val >>= 2;
	a[4] = val & 0xf;
	val >>= 4;
	a[3] = val & 0xf;
	val >>= 4;
	a[2] = val & 0x3f;
	val >>= 6;
	a[1] = val & 0x3;
	val >>= 2;
	a[0] = val & 0xf;	

}

int TTimeZone::GetTimeZoneBias(int ndst)
{
	return gzone[ndst].bias;
}

int TTimeZone::GetDaylightTimeStartDate(int nDst, int nYear, VCTIME &vcStart)
{
	int a[8];
	ExpandVal(gzone[nDst].val, a);
	vcStart.day = 1;
	vcStart.month = a[0];
	vcStart.year = nYear;
	if (a[1] == 1)
	{
		vcStart.day = a[3];
	}
	else
	{
		if (a[2] == 5)
		{
			vcStart.day = GetMonthMaxDays(nYear, a[0]);
			vcStart.InitWeekDay();
			while (vcStart.dayOfWeek != a[3])
			{
				vcStart.PreviousDay();
				vcStart.dayOfWeek = (vcStart.dayOfWeek + 6) % 7;
			}
		}
		else
		{
			vcStart.day = 1;
			vcStart.InitWeekDay();
			while(vcStart.dayOfWeek != a[3])
			{
				vcStart.NextDay();
				vcStart.dayOfWeek = (vcStart.dayOfWeek + 1) % 7;
			}
			vcStart.day += a[2] * 7;
		}
	}
	vcStart.shour = 1/24.0;
	return 0;
}

int TTimeZone::GetNormalTimeStartDate(int nDst, int nYear, VCTIME &vcStart)
{
	vcStart.day = 1;
	vcStart.month = 10;
	vcStart.year = nYear;
	vcStart.shour = 3/24.0;
	return 0;
}


int TTimeZone::GetID(const char *p)
{
	int m = GetTimeZoneCount();
	for(int i = 0; i < m; i++)
	{
		if (stricmp(p,TTimeZone::gzone[i].name) == 0)
			return i;
	}
	return atoi(p);
}
