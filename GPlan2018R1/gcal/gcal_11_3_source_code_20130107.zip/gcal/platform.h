#ifndef _GCAL_PLATFORM_HDR__
#define _GCAL_PLATFORM_HDR__

typedef unsigned char UInt8;
typedef unsigned short UInt16;
typedef unsigned int UInt32;
typedef char SInt8;
typedef short SInt16;
typedef int SInt32;
typedef bool Boolean;

#include "TString.h"

#endif