// PORTABLE

#ifndef _STRINGS_GCAL__
#define _STRINGS_GCAL__

#include "TString.h"

extern TString gstr[];
extern int gstr_Modified;

void InitGlobalStrings(int);

#endif