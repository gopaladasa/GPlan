#ifndef _SHOWSET_GCAL_2008___
#define _SHOWSET_GCAL_2008___


class CShowSetting
{
public:
	int val;
	int old_val;
	char * sig;
	char * text;
};


#endif