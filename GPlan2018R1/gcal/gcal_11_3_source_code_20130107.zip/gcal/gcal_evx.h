#ifndef __GCAL_EVX_H______
#define __GCAL_EVX_H______

const char *AvcAllocString(const char *str);
char * AvcAllocMemory(int nLen);


#endif