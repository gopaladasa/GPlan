CR-200901
old structure

current.cfg - actual settings for application
cevents.cfg - custom defined events
locations.cfg - locations
showset.cfg - settings of display

new structure

cex.rl - "event manager" file (cevents)
locx.rl - "location manager" file (locations)
var.rl - variables in GCAL file (showset + current)
app.rl - other not frequently changes settings

--------------------------------------------------------
CR-200902

storage of countries on disk
storage of strings on disk

-----------------------
CR-200903

5. In the dialogs for entering gregorian month, day, year, hour, minute when
adding a custom event, if you mistype and get an error message, you have to
click "OK" twice to get the error message to clear.

6. Now that you have added the Event Manager screen, is there any need to
show the standard events on the "Custom Event Manager" screen? Perhaps it
should just start out as a blank screen, and then just show whatever custom
events are added. It can also be confusing, as if a user adds a custom
event, then it may be hard to later find it in the listing among all the
standard events, especially since the sorting is by masa, paksa, and
tithi!!! But if there are only the custom events then it should be easy to
work with.
