==============================================
    GCAL  Quick Installation
==============================================

1. unzip gcal.zip file
2. copy files gcal.exe and gcal.chm to your local drive
3. gcal.exe and gcal.chm has to be in the same directory
4. run gcal


Copyright (C) 2009, ISKCON Governing Body Commission Society
